<html>
<head>
<title><? include('title.php') ?> :: How To Design Your Own Halloween Costume</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>How To Design Your Own Halloween Costume&nbsp;&nbsp;</H1><FONT size=-1> by Nicola Kennedy</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Designing your own Halloween costume can be easier than you might think. All it takes is a little time and some imagination. Start by deciding exactly what you would like to be for Halloween. Once you have made this decision your next step would be to collect the necessary materials to design the perfect costume. Be sure and allow yourself enough time to work on the costume, that way if you end up missing an important item you still have time to go out and pick it up. Waiting for the last minute is not a good idea. <P>Angel - For an angel costume you would need some white material for the body of the outfit. You can purchase some thin, easy to work with wire from most any craft department store. Use this to construct the halo that fits perfectly around your head. Also, pipe cleaners can be used for this. Dress it up by using lace or some type of silky material to sew around as a covering. Some white or gold color material would look perfect for the angel's wings. Sew some wire through the edges of the wings to help them stand out. <P>Witch - Have you always wanted to be a witch for Halloween? If so, you simply start by purchasing the black material. Just sew a simple pull over dress then use a belt to pull it tight around your waist. You can either buy a black belt or sew one from left over material. Cut the bottom in a zigzag to add a touch of flare, add some black boots, an old broom for a prop and of course, the pointed black hat. If you want to make the hat yourself you can do so by using cardboard to form the wide brim pointy design and glue the black cloth to the outer surface of the cardboard. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Animal - Perhaps a cute little animal such as a cat, dog or even an adorable little bunny is more what you are looking for. Pipe cleaners sewed to a strap for support make wonderful whiskers, or just use a makeup pencil to color them on. Ears can be made by sewing together material with just enough stuffing to give them shape and body. Sewing wire along the edges of the ears will allow them to be shaped into different positions. To make a tail for a cat or dog you simply need to cut out and sew together a piece of material the correct length. Next, add the stuffing to give it the depth it needs then sew it onto the rest of the costume. A big ball of cotton glued onto a bunny outfit makes a perfect Peter Cotton Tail.<BR> <P><B>About the Author</B></P> <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>Nicola always enjoys Halloween parties. Visit her Halloween site for tips and information about <A href="http://homemade-halloween-costumes.best-halloween.com">Homemade Halloween Costume Ideas</A> at <A href="http://Homemade-Halloween-Costumes.Best-Halloween.com">http://Homemade-Halloween-Costumes.Best-Halloween.com</A> <P>This article may be reprinted in full if the resource box and the live links are included intact. Copyright <A href="http://www.best-halloween.com">Best-Halloween.com</A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>