<html>
<head>
<title><? include('title.php') ?> :: Tips to Make Halloween Party - a "Superstitious" Party</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Tips to Make Halloween Party - a "Superstitious" Party&nbsp;&nbsp;</H1><FONT size=-1> by Mitch Johnson</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Every child wants their Halloween party to be the scariest, thrilling and chilling. They come up with new motives of dreary decorations and exciting games to give horrible shock to their friends so that the party will be remember for a long time. In this article you will find some important tips on how to arrange a perfect Halloween party. <P>October brings that bright blue weather poets sing about and it also brings that traditional night of nights when witches, bats, owls, black cats and goblins are on the prowl in step with the moaning wind in ghostly tree tops. <P>What could be more perfect on such a night than to have the High School gang in for a Halloween party. No other party is such fun to give with all of spook Dom ready to do your bidding to add to the party atmosphere. And if you make your party a "superstitious" party you can give your games that different touch that will make your party the talk of the crowd for many a day to come. It will start the social season off with a bang. <P>Trim your house from top to bottom with black cut-outs of witches riding the broomstick, black cats, owls, and grinning jack-o-lanterns. Add to this usual decoration plenty of superstitious symbols to carry your party theme. Cardboard horseshoes can grace the doorways and huge four-leaf clovers decorate the drapes. In one corner suspend an open black umbrella decorated with bright orange streamers that reach to the floor. This colorful canopy will house your gypsy queen when she tells the fortunes of the willing guests. <P>Set the pitch for your party with invitations inscribed in white ink on black cut-out skull and cross bones: BEWARE! Bring your luck with you Friday night, October 31 To Bob Wyman's at 8.00 P.M. YOU'LL NEED IT! Be a black cat when you greet your guests at the door and hand each one a rabbit's foot to guard him well as he walks under the tall stepladder arching the doorway. Your black-cat costume need be no more than a black-cat mask and a black rope tail fastened under your belt. If the rest of your clothes are dark it will carry the catty illusion. <P>Usher the girls into a room so dimly lighted they'll not loiter long to primp. A long, jagged, black crayon mark drawn diagonally across the mirror will remind them that bad luck is loose in the house tonight. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>A huge number 13 over the door of the boys' room will warn them of the peril of the night as well as huge black-cat cut-outs taped to the walls. <P>Before the party type a list of Bad Omens or Superstitions, one to a card. Then cut each card into several pieces. Scramble them and place several pieces in each envelope. Hand an envelope to each guest as he enters. By exchanging pieces with the other guests he can get the right pieces to formulate one complete superstition. Here are some familiar superstitions to use: 1. A broken mirror will bring you seven years of bad luck. 2. If you sing before breakfast you will cry before night. 3. If a black cat crosses your path you will have bad luck. 4. To walk under a ladder is extremely bad luck. 5. You'll never finish anything started on Friday. 6. If you put on a garment wrong side out it's bad luck to change. 7. It's bad luck to sneeze before breakfast. 8. It's bad luck to rock an empty chair. This mixer will give the guests something to do immediately upon arrival and avoid any stilted, awkward moments. <P>Next seat the guests on the floor in two lines facing each other. Appoint the first man of each line captain. Give each captain a double handful of Bad-Luck Corn. Instruct him to lay his Bad Luck (Corn) in a pile in front of his neighbor. <P>The object of the game is to see which team can first pass the corn down the line and back. Any spilled corn must be gathered up and passed along. It's quite a trick to pass this much corn fast without dropping kernels.<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Mitch Johnson is a regular writer for <A href="http://www.kids-games-n-crafts.com"><A href="http://www.kids-games-n-crafts.com/">http://www.kids-games-n-crafts.com/</A></A> , <A href="http://www.mycostumeshub.info"><A href="http://www.mycostumeshub.info/">http://www.mycostumeshub.info/</A></A> , <A href="http://www.mycostumesresource.info/"><A href="http://www.mycostumesresource.info/">http://www.mycostumesresource.info/</A></A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>