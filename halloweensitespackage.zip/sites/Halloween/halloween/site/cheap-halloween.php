<html>
<head>
<title><? include('title.php') ?> :: Haunted House design - Designing the Facade</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Haunted House design - Designing the Facade&nbsp;&nbsp;</H1><FONT size=-1> by Paul " DragonMaster " Pendragon</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>DESIGINING YOUR HAUNTED HOUSE / ATTRACTION <P>From decorating your home, to a haunted house to raise funds, to a haunted house for profit certain things pertain to all and can help whatever you do be more successfull. In a series of articles I will attempt to help you design and build whatever you desire for halloween and make it more successfull, and more exciting. Remember you do not have to spend alot of money, but it will take time, imagination, and hard work. <P>Everyone who has a home haunt always works on the outside the most, as the outside is what most people see. However a haunted house as a fundraiser or for profit haunted attraction often spends more time on the inside then they do on the part of the attraction people will see first. We are always told that first impressions mean the most, and that applies in a big way to haunted attractions. You need to set the stage for your visitors, and you need to prepare them for what is inside.. <P>The facade is so important as they are what people see first, and it is what sets the stage and starts the frightning of the guest. Part of scaring people is the anticipation that something is going to happen. So your facade and queline should give your visitors the feeling that something dangerous and ominous is going to happen. Visitors will be prepared for your first scare before they ever enter your attraction. <P>For home haunts most visitors will not enter your house. They will simply walk up to get there treats so the outside of our home and the areas leading up to the door is so very important so that trick or treaters get the feeling that this is the house they want to visit time and time again. <P>First you should pick a theme for this halloween year. Between haunted houses if I am going to be home for halloween I always pick a theme. And of course if I am designing and building a haunted house the theme is so very important. In a home haunt you are decorating for the season, in a haunted house to raise money or for profit you are telling a story. Without the story your visitors will be more confused then scared as to what is going on in your attraction. <P>WALKING UP TO THE HOME HAUNT OR HAUNTED ATTRACTION. <P>Your planning and decorating should go from the road up to your home or attraction. Everyone should be in costume and the costume should fit the theme in one way or another. <P>The first thing to remember in planing the walk from the road to the entrance / door of your house or attraction is lighting. While our tendency is to make things dark and scary the walk to the entrance should be well lighted for safety sake. Depending on your theme you can use pumpkins, tiki torches, luminares, or alternative forms of lighting so that visitors to your home or attraction can get to the door without tripping or falling. Make sure walkways are at least 40 inches wide to accomodate wheelchairs or small children clinging to a parent. <P>Refrain from using strobe lights on the outside of your home or haunted attraction close to the walkway or where the lights will hit those walking towards your home / haunted attraction. Strobe lights can trigger seizures, migraines, or other physical problems in some individuals. If strobes are used at all they should be used in a way that they do not directly point to, or in the view of visitors. <P>Also ensure the walkway is clear of debris or props that may trip someone or cause them to fall. And I will make the point now and later. Never let an actor touch someone ! Touching a guest is a liability especially if the person falls. Also I want to mention that some people coming to your home / haunted attraction may suffer from panic attacks, and / or anxiety attacks so we want to make sure they get to the door without having to call an ambulance. In the case of haunted attractions warnings usually are posted only at the entrance, and waivers are signed until a person gets ready to enter. So if a person " freaks out " and has a medical emergency, or falls, you will be liable for any injury. <P>FACADE <P>The facade is the outside of your home or haunted attraction and in the case of the haunted attraction most likely will include your ticketbooth and your warnings for visitors who should not enter the attraction. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>The first thing to consider is our windows. A cheap simply approach is to use the plastic window clings you can buy in most stores. A more expensive but better approach is to set up a Peppers Ghost Illussion in your windows so it appears there are ghost awaiting the guests walking up. You can check out my website www.pendragonscastle.com/hauntmasters for more on this illussion and how best to use it. <P>Next are the walls which you won't want to mess up with nails or adhesive. Scene setters which are available from my party store is a good alternative for this. Scene Setters can be held up with tape so you won't damage your home or building. Scene setters come in many wall designs and also include decorations that attach to the scene setter to complete the affect. <P>If you want to build a frame you can use styrofoam to make a fake brick look to the outside with a little trimming and paint. Add a few old boards and you have a great look. Be sure that all the items you use on the outside of your home or building are firmly attached so they won't fall on someone. Many times over the years a scared visitor made their own exit which included tearing down part of the facade that I forgot to firmly attach. <P>Once you have the walkway lighted, you have covered windows, walls. You can add smoke, specialty lighting ( caution on the strobes ) and spread a few bones, chains, skulls and whatever you can get to add to the effect. <P>Halloween has evolved to the point that many stores sell motion activated props that you can use outside your home or haunted attraction. Use these when you can but remember. Most motion activated props work on the principal that when a person walks in front the light level changes setting off the prop. If the area where you use this prop is to dark then it won't work. Some of the props are sound activated. This solves the light problem but one prop can set off another prop atc. so you loose the effect you want. Make sure you test all of your props and effects prior to the opening of your attraction, or in the case of the home haunt halloween night so you get the maximuim scare value you need <P>You can find more articles on Halloween at my website at www.pendragonscastle.com you can also find more articles, tips, etc at www.pendragonscastle.com/hauntmasters. On both sites you will find articles, tips, ideas, and a great merchandise section where you can buy all the great stuff you will need for this halloween season. <P>Paul Pendragon has been designing home haunts and haunted attractions for twenty seven years and is co-founder of The House of Pain Haunted House in Middle Tennessee. He is also founder of Pendragons Castle a Halloween / Entertainment site. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P><BR> <P><B>About the Author</B></P> <P>Paul Pendragon is founder of Pendragons Castle and DragonMaster Entertainment. He is co-founder of the highly successfull House of Pain Haunted House. He has been designing Haunted House for 30- years you can visit his site at <A href="http://www.pendragonscastle.com">http://www.pendragonscastle.com</A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>