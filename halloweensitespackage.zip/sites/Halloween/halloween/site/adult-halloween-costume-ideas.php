<html>
<head>
<title><? include('title.php') ?> :: 10 steps for planning a Halloween Party | Creative and creepy Halloween ideas for revelers of all ages</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>10 steps for planning a Halloween Party | Creative and creepy Halloween ideas for revelers of all ages&nbsp;&nbsp;</H1><FONT size=-1> by Daryl plaza</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P><B>10 steps for planning a Halloween Party | Creative and creepy Halloween ideas for revelers of all ages</B> <P> <P>The sky is darkening. You feel a chill and ghostly horrors in the air as the moon shines brightly on this cloudless night. It is the last night of October, October 31st. It is officially Halloween night and you have decided to have a hauntingly exciting Halloween party. How ghoulishly delightful! But where do you start in planning your Halloween holiday celebration. Here are 10 steps to help you in planning a great Halloween Party that will have all those ghosts, wicked witches and grim goblins screaming with delight. <P> <P><B>Step 1: Halloween Party Kickoff:</B> Think about who the party is for - for you or your children? An adult Halloween party will be quite different from a children's Halloween party when it comes to planning the Halloween theme of the party, Halloween decorations, Halloween recipes and beverages. Adults and older children usually love to be frightened, but that is not the same for smaller children. So when planning your event keep the ages of your guests in mind. Once you have that figured out, now it is time to pick the date, time and place of your Halloween party. And don't forget the guest list. <P> <P><B>Step 2: Halloween invitations:</B> This is where you can have fun and set the mood of your unforgettable night of horror chills and thrills by sending out unique and spookily inviting Halloween party invitations. You can purchase them or make some yourself with some construction paper and some glitter markers, or how about buying some inexpensive Halloween paper eye masks and writing the words on the back. Include all the important information such as date, time, place and a request for RSVP to your Halloween party. <P> <P><B>Step 3: Halloween party food and recipes:</B> now the party would not be a party without a lot of great Halloween munchies. Plan a menu and write out your shopping list. Try to do as much in advance as possible, and try to pick Halloween recipes that can be made ahead and stored or frozen. And again, think of the ages of your guests - there are a lot of fun Halloween foods for both kids and adults. Here might be the place to use up some of those Halloween pumpkin guts. <P> <P><B>Step 4:Haunted Halloween Pumpkins:</B> plan to buy your pumpkins early to get the best selection. By selecting a variety of shapes and sizes of pumpkins, you will be able to make a variety of interesting jack-o-lanterns ghosts. And don't forget about those miniature pumpkins, they can make great party favors or Halloween decorations also. And the day before the party, carve your pumpkins and double check you have enough candles or use small flashlights to show off their ghostly grins. <P> <P><B>Step 5: Halloween Costumes:</B> there is always something exciting about putting on a Halloween costume and taking on another identity. So prepare yourself and your families Halloween party costumes in advance so that you don't have to run around in a panic trying to put something together at the last minute. It is easy to find a lot of great Halloween costume ideas that will not cost a lot of money or time. <P> <P><B>Step 6: Halloween Party Games or Activities:</B> Halloween games and craft activities are especially popular for younger Halloween party guests, but this does not mean that adults would not enjoy the fun of Halloween games and showing off their ghostly talents. So think about what Halloween activities your guests would be interested in and gather all the materials you need in advance. Also be sure to have some extra Halloween activities incase a game that you are expecting to take 45 minutes only lasts for 20. And do not forget the Halloween prizes, these can be easily and inexpensively assembled by a quick trip to your local novelty or dollar store or ordered online to be delivered straight to your door. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P> <P><B>Step 7: Halloween music and sounds:</B> there is no time then the present to start thinking about what kind of Halloween music you want at your Halloween party celebration. Are you looking for some fun party songs for dancing music, or hauntingly spooky background ghost music for a dinner party, or a collection of sing-a-longs for the kids. Also, you might want to incorporate some Halloween special effects outside with spooky horror sounds as your guests walk up to the front door. There are a lot of special music tapes or CD's available to purchase, or if your try making one on your own - it could be almost as much fun as the Halloween party itself. <P> <P><B>Step 8:Halloween Party Favors:</B> party favors add an extra treat of fun to any Halloween party and are a wonderful addition as a Halloween treat for each guest or something they can take home. They do not need to be elaborate Party Favors or costly and can range from a small plastic toy to a homemade individual bundle of snack mix wrapped in Halloween decoration style. <P> <P><B>Step 9: Halloween Decorations:</B> decorations for your front yard and house for Halloween can be a lot of fun and again does not need to be costly. You can get a lot of great eerie Halloween effects by experimenting with some horror lighting placed around your indoor and outdoor Halloween decorations. And adding in some Halloween music or ghost sounds can make some of your Halloween decorations come to life. <P> <P><B>Step 10: Party Guests Arrival:</B> today is the day - Halloween party Night, and your guests are about to arrive. Have a quick look around to see if all is in order and that your house is a safe setting. Keep a porch light on so everyone sees any steps or other obstacles, and make sure all your guests have a way back home after the Halloween festivities come to an end. <P> <P><B>Final note:</B> Remember that your Halloween party does not need to be elaborate, the main component of a great Halloween party are a few willing participants that want to have fun, a few simple Halloween decorations and props, toss in some spooky music and ghost sounds, and definitely the Halloween food - and you will have a smashingly and howling Halloween Party. So when the party starts, enjoy yourself! It will be a spookily great time.<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Daryl Plaza is the owner of<A href="http://www.spookynite.com/halloweencostume-.html "><B> spooky night.com</B> </A>a website with reviews and resources on<A href="http://www.spookynite.com/halloweenrecipes.html"><B> Halloween recipes</B> </A>, costumes, music and decorations</P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>