<html>
<head>
<title><? include('title.php') ?> :: Remembering Homemade Costumes Of Yesteryear</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Remembering Homemade Costumes Of Yesteryear&nbsp;&nbsp;</H1><FONT size=-1> by Jean Rennick</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>A Boy and his Imagination <P>A few years ago my youngest son decided long before Halloween that he had his costume all figured out. He wouldn't share the secret, only said that he had everything he needed to make his best Halloween costume ever. <P>His joy in planning and preparing for Halloween using things available around the house reminded me of the homemade (and sometime last minute) costumes I'd worn over the years. <P>Costumes of Halloween Past <P>I remember one year, I believe it was grade 1, that I dressed as Casper the Friendly Ghost. I paraded around the school dressed in my white sheet feeling like I had the best costume ever! <P>Another year, my mother spent hours making costumes for my sister and me. I went as a skeleton. My costume consisted of a huge black plastic bag, on which my mom had attached several "bones" made out of white paper. My mask was a white paper plate that had been cut to the approximate shape of a bare skull. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>My sister's costume was much more elaborate. She trick-or-treated that year as a shaggy dog. The head and body were made of two large cardboard boxes. The shaggy part was made with hundreds of precisely cut strips of old newspaper, curled with scissors and pasted to the boxes. <P>These costumes may not seem like much, but they are among the few that I remember well from my childhood. One other costume I remember was homemade more out of haste than anything else. It was the last year I went trick-or-treating. I must have been 13 or 14. I had resolved not to go out, but at the last minute, changed my mind. I ran into my dad's body shop, grabbed a shop coat and a mask that he used when painting, and collecting a pillowcase on the way out, I was off. I'm not even sure what I was dressed as, but it was fun! <P>Back to the Boy <P>Halloween arrives, and my six-year-old son takes his dad to his room and explains what he needs for his costume: safety pins and a mask made from black construction paper. A short time later, he announces he is ready, and "Batman" comes into the hallway. His costume consists of a black cape (an upside-down black t-shirt safety-pinned to the black shirt he's wearing), a mask (fashioned from construction paper), a symbol (drawn on a white piece of paper and taped to his shirt), and a utility belt (also made of white paper). He has never been more satisfied with a Halloween costume than the day he made his own!<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Jean Rennick loves Halloween. This year, she's thinking of ditching the witch costume and reliving the skeleton costume! For help in choosing this year's <A href="http://halloween.getcelebrating.com/Halloween_Costumes.html">Halloween costume</A>, head over to <A href="http://Halloween.GetCelebrating.com">http://Halloween.GetCelebrating.com</A>.</P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>