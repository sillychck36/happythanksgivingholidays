<html>
<head>
<title><? include('title.php') ?> :: Some Ideas for Your Halloween Party Game</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Some Ideas for Your Halloween Party Game&nbsp;&nbsp;</H1><FONT size=-1> by Mitch Johnson</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Lets have a good look on some of the funny, chilling, thrilling and interesting Halloween party games. These games can be played by all age group. If you are planning to invite all your friends and friends family, then you must surely try out these games. <P>A "Cat Race" next kept the guests busy. Before the party our sons had cut out of black construction paper two large cardboard cats. A string about twelve feet long was run through the head of each cat. One end of each string was tied to a chair across the room high enough from the floor so that each cat stood on its hind legs. <P>Then the captains of each team took the loose ends of the strings and by jerking them moved the cats down to the man operating the string. The next man in line jerked the cat back up to the chair. Of course, the first line through won the race. It was a hilarious race that left the jerkers helpless with mirth. <P>The next game was a relay and the guests were divided into two teams. A big orange cardboard pumpkin with a large opening in one side hung in an open doorway. Suspended inside the pumpkin was a small bell. The first man on each team was given a bean bag and told to ring the bell. Each player had one try and then passed the bean bag to the next player. A scorekeeper reported on which team rang the bell the greater number of times. <P>Then apples were tied to strings in the open doorway. A contestant with hands behind his back tried for a bite at the swinging apple. In a large archway there is room for five or six apples hung side by side. It is loads of fun for the onlookers to watch the struggling contestants. <P>The "Rainy Day Race" was really hilarious. Once again we divided the guests into two teams. A locked suitcase and an umbrella were given each side. Each suitcase contained rubbers, a skirt, gloves, a raincoat and hat. At the starting signal the leader of each team opened the suitcase, put on the clothing, went out the front door, raised the umbrella and ran around to the back door through the house to the living room, where he closed the umbrella and repacked the suitcase for the next man on his team. Needless to say the repacking and dressing was done at break-neck speed and afforded no end of fun and excitement . After this riotous event the guests welcomed a chance to catch their breath. While they were resting each one was given a clothespin, a Halloween paper napkin, three straight pins, and a yard of string to make a Halloween table favor. <P>When the favors were finished and the winners chosen, the guests were led to Goblin's den our dining room for the buffet lunch. The tablecloth was black crepe paper. A two-faced lighted pumpkin served the double purpose of centerpiece and illumination. White cut-out skulls and crossbones and large white cat-heads with wide-open mouths and eyes added a lot to the spookiness of the table. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Each guest carried his filled plate to the living room where card tables had been placed. To match the dining table each card table was covered with a black crepe-paper cloth. Scattered over the table top were white cut-out skulls and crossbones. Each table was lighted with an orange candle decorated with a black crepe-paper bow. White grave markers served as place cards. These markers, held erect with stiff cardboard standards, bore such inscriptions as "Here sits spook Tom Jones." <P>The food too carried out the Halloween idea. Jack-o-lanterns made from red apples were stuffed with tuna-fish salad. Open-faced cheese spread sandwiches with raisin features grinned a welcome. Wedges of pumpkin pie were decorated with skull and crossbones of whipped cream. The children were served glasses of witch's brew (cider) and the adults were given coffee. <P>After the luncheon all went in to see "Mike" our family skeleton who holds forth in a dark closet on Halloween night. Mike is a life-size cardboard skeleton purchased from the dime store. We painted his bones with phosphorous paint and he glows realistically from a darkened closet. <P>By all means give a family Halloween party. It is such a good chance to have fun and be completely natural<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Mitch Johnson is a regular writer for <A href="http://www.celebrex-n-vioxx-alternatives.com"><A href="http://www.celebrex-n-vioxx-alternatives.com/">http://www.celebrex-n-vioxx-alternatives.com/</A></A> , <A href="http://www.costumesforu.info"><A href="http://www.costumesforu.info/">http://www.costumesforu.info/</A></A> , <A href="http://www.goodbudgetholiday.info/"><A href="http://www.goodbudgetholiday.info/">http://www.goodbudgetholiday.info/</A></A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>