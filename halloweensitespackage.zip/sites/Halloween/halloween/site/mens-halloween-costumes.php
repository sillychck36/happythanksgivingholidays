<html>
<head>
<title><? include('title.php') ?> :: A Word About Sexy Costumes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>A Word About Sexy Costumes&nbsp;&nbsp;</H1><FONT size=-1> by James Newton</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Halloween! My favorite time of year. I remember being a kid and getting to run around the neighborhood with complete anonimity. Collecting enough candy to last for months. Scaring the cute little girl that wouldn't give me the time of day, getting revenge on various members of the neighborhood with a little fake blood and some toilet paper. Yes, Halloween has some sweet childhood memories. <P>One of the great things about Halloween is that I can still revert to a boyish behavior and have fun, no matter how old I get. I don't "roll" anyone's yard anymore ... although the thought is a little tempting. The only candy I collect on Halloween nowadays is, eye candy. Wow! Those women and their sexy costumes! Halloween, to the benefit of mens' vision, seems to provide the gals with the perfect excuse to dress sexy. <P>Women who are normally conservative dressers can use Halloween to drop their inhibitions, and tease us to no end. Women for whom I have hardly given a second look, can suddenly find themselves locked in my intense gaze. Geeze, ... I never knew they had a figure. On Halloween, I can go to any bar and get an eye full of sexy little witches, nurses, cowgirls, geisha girls, Daisy Dukes, kitty cats, race car drivers, little indian squaws, biker babes, french maids, and the list of hot costumes goes on and on. I find my eyes doing a "pinball stuck between two bumpers" impression. Ping, Ping, Ping, Ping... My neck might be sore the next morning from all the neck snapping. <P>Yes, as kids we got to drop our inhibitions, and we still do. Maybe that is part of the allure, the good get to be bad, for just one night of the year. We get to let the actors and actresses out in each of us and pretend to be something we are not. Something about that can be a real turn-on. In fact, I wonder if the birth rate increases in July? And if it does, could it be because of those hot costumes, or just us letting our Halloween spirits free? <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>I'm not a psychiatrist, but I am betting this is a healthy thing. Even if it is for one night, and in a limited capacity, that kind of freedom has to be good for your mental health. <P>As Halloween nears, I look forward with great anticipation. What will I wear? Maybe I should just go natural...be the wolf that I am. That sounds about right. When I think about those hot costumes, I want to start howling at a full moon. I'm not sure yet, but you can bet, whatever I wear, my eyes will be shaded, so they will be free to get all the eye candy they can handle. <P> <P>I would love to hear your halloween stories. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Jim and Edie own and operate a lingerie shop. They enjoy providing all things romantic including writing about it at <A href="http://www.sweetdeal4u.biz">Hot Stuff Leather and Lace</A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>