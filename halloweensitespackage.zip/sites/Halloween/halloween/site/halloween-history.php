<html>
<head>
<title><? include('title.php') ?> :: The History of Halloween Music</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>The History of Halloween Music&nbsp;&nbsp;</H1><FONT size=-1> by EZ Tracks</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Some may debate whether Bobby Pickett's "Monster Mash" or the beginning of Johann Sebastian Bach's "Toccata and Fugue in D minor" was the first music to unequivocally be associated with Halloween, while other's may insist that nothing truly scary made an impact on the national consciousness until the Starland Vocal Band released "Afternoon Delight". <P>No matter what you associate musically with Halloween, the songs and themes that seem to pop up year after year around October 31st have certainly made an impact. Unlike Christmas Music, which has a rich tradition (aside from the deplorable "Grandma Got Run Over By A Reindeer"), Halloween music is almost exclusively a product of the 20th century. <P>The number of purely musical releases are few and far between. Most recognizable Halloween themes were a byproduct from the film and television industry. Consider Ray Parker Jr's "Ghostbusters", which was originally titled "I Want a New Drug" and performed by Huey Lewis and the News. It not only rose to the top of the charts, but has also enjoyed many subsequent years of airplay because of the Halloween season, much to the chagrin of anyone who can't appreciate the beauty of rhyming "dose" with "ghost". <P>Even more popular are the sound bites from various horror franchises. Who can forget the busy yet astonishingly creepy theme to John Carpenter's "Halloween" or the scary, slow building strings that John Williams wrote for Steven Spielberg's "Jaws"? And dare we not include Celine Dion's "My Heart Will Go On" from the movie Titanic. Talk about frightening! <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Indeed, movie and TV themes such as "The Twilight Zone", written and performed by Neil Norman &amp; His Cosmic Orchestra, seem to resonate with more appeal than novelty songs written with monster mayhem in mind. Personally, I blame the song "The Blob" which was written and performed by the ingeniously named The Five Blobs for setting a terrible precedence. It's not easy to adequately convey the urgent need to "be careful of the blob" with monotone vocals and music that sounds fresh from an Annette Funicello, Franky Avalon surf picture, but somehow all five blobs managed. <P>No matter what music puts you in the mood for frightening fun this Halloween season, it's almost a given that you'll hear it somewhere. Whether it comes from the television, the radio, or via the humming of that co-worker in the cubical next to your who you never were all that sure about, Halloween music is indeed here to stay. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>To learn more about The <A href="http://www.ez-tracks.com/history_of_halloween.html">History of Halloween</A> You can also <A href="http://www.ez-tracks.com/Halloween.html">download Halloween music for free</A> on our site. Read articles on <A href="http://international-music.blogspot.com/">International Music </P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>