<html>
<head>
<title><? include('title.php') ?> :: Haunted House Design - Designing the Queline</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Haunted House Design - Designing the Queline&nbsp;&nbsp;</H1><FONT size=-1> by Paul " DragonMaster " Pendragon</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>DESIGINING YOUR HAUNTED HOUSE / ATTRACTION - THE QUELINE <P>From decorating your home, to a haunted house to raise funds, to a haunted house for profit certain things pertain to all and can help whatever you do be more successfull. In a series of articles I will attempt to help you design and build whatever you desire for halloween and make it more successfull, and more exciting. Remember you do not have to spend alot of money, but it will take time, imagination, and hard work. <P>Everyone who has a home haunt always works on the outside the most, as the outside is what most people see. However a haunted house as a fundraiser or for profit haunted attraction often spends more time on the inside then they do on the part of the attraction people will see first. We are always told that first impressions mean the most, and that applies in a big way to haunted attractions. You need to set the stage for your visitors, and you need to prepare them for what is inside.. <P>The facade is so important as they are what people see first, and it is what sets the stage and starts the frightning of the guest. Part of scaring people is the anticipation that something is going to happen. So your facade and queline should give your visitors the feeling that something dangerous and ominous is going to happen. Visitors will be prepared for your first scare before they ever enter your attraction. <P>For home haunts most visitors will not enter your house. They will simply walk up to get there treats so the outside of our home and the areas leading up to the door is so very important so that trick or treaters get the feeling that this is the house they want to visit time and time again. <P>First you should pick a theme for this halloween year. Between haunted houses if I am going to be home for halloween I always pick a theme. And of course if I am designing and building a haunted house the theme is so very important. In a home haunt you are decorating for the season, in a haunted house to raise money or for profit you are telling a story. Without the story your visitors will be more confused then scared as to what is going on in your attraction. <P>QUELINE / FOYER <P>The queline is the area where your visitors wait in line prior to going into the attraction. For some haunts this is outside prior to buying tickets. For those haunted see my article on decorating the facade available at both <A href="http://www.pendragonscastle.com">http://www.pendragonscastle.com</A> and at <A href="http://www.pendragonscastle.com/hauntmasters">http://www.pendragonscastle.com/hauntmasters</A> For those home haunts / and haunted attractions where there is an inside waiting area lets continue. <P>Ensure that prior to buying tickets you have a sign with a warning for visitors to read. The sign should state who should not enter the attraction and that you are not liable for accidents etc. A great sign idea can be found at <A href="http://www.pendragonscastle.com/hauntmasters">http://www.pendragonscastle.com/hauntmasters</A>. After the visitors purchase their tickets they should enter the foyer area where they will sign a waiver a great one is available at <A href="http://www.pendragonscastle.com/hauntmasters">http://www.pendragonscastle.com/hauntmasters</A>. If your attraction is in chromographic 3-D here is where they will get glasses etc. If your attraction has guides this is where they will pick up there guide. My policy is this, if they have not left the queline/foyer area I will give them their money back, once they enter the attraction there are no refunds. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Depending on your theme I like to use a funeral parlor theme for this area. You can have a queline video that goes over the rules which also should be posted as a written signs, an example can be found at <A href="http://www.pendragonscastle.com/hauntmasters">http://www.pendragonscastle.com/hauntmasters</A>. Again try and ensure that there is 36 to 40 inches of walking space for wheelchairs and to ensure there is no trip hazard. Ensure all props are properly secured. Make sure all actors stay in character while in this area. <P>In all my years of doing haunted attractions where there are volunteers this queline area always fills with actors wanting to have a smoke while everyone waits for the next car to drive up. You need to discourage this as much as possible. When a car drives up if they see a bunch of actors half in - and half out of costume it ruins the affect. <P>Also actors will have a tendency to follow visitors out to the parking lot so they can get that one final scare. This is also a practice you need to discourage. Chasing visitors out to the parking lot can cause accidents and falls which can cause a liability problem. <P>Decorate your foyer with scene setters. Lots of low lighting, etc to give it an ominous look. Have your table for signing waivers with a couple of the rules and the warnings above it. Try not to use strobe lights in a way that they could trigger seizures or panic attacks. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Paul " The DragonMaster " Pendragon is co-founder of the highly successfull House of Pain Haunted House and founder of Pendragons Castle. He has been designing Haunted Houses for close to thirty years</P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>