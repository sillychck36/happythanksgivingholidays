<html>
<head>
<title><? include('title.php') ?> :: How much do you know about Halloween?</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>How much do you know about Halloween?&nbsp;&nbsp;</H1><FONT size=-1> by S. Roberts</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>How much do you know about the spooky holiday of Halloween? As you probably know, Halloween is celebrated on the 31st October and the name Halloween descends from the old name Hallows Eve, the night of the dead. This is why children and adults alike dress up as spooky characters suck as ghosts, goblins, vampires, monsters, witches and anything that goes bump in the night. <P>It is also said that on this night dedicated to the dead, that there are more spiritual energies, making it a more receptive night to contact the dead, and for the dead to contact the living. <P>Halloween is often considered an American festivity, so it might surprise you to know that it originated in Ireland as the Pagan Celtic harvest festival Samhain. Halloween wasn't exported to America until the 19th century, when many Irish folk emigrated. <P>The Celts celebrated as their harvest festival because by the end of October all the hard work of harvesting the crops was over. They also saw Halloween as marking the time when the days would shorten and there would be darkness and coldness of the winter season. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Many Christians prefer to celebrate the following day, All saints day on 1st November (also know as 'All hallows' and 'All souls day') This is to avoid conflict with their religious beliefs. The word hallow means sanctify in old English, 'to free from sin'. All saints day is therefore considered to be a day of goodness. <P>Halloween and its festivities have now been spread to most of the western world. However, the old Halloween meaning has been lost and replaced. Nowadays Halloween is seen as a festive holiday of fun and spookiness. A time to dress up and have a fun time, maybe to go 'trick or treating' or to go to a spooky Halloween part. Halloween is a time to spook yourself, or maybe someone else, BOO! <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P><BR> <P><B>About the Author</B></P> <P>S. Roberts is a ghost hunter and medium extrordanaire. Visit her live Halloween Special Ghost Cam. If you do sight a ghost please report it. Thanks. If you use this article please link to <A href="http://www.affiliate-exchange.co.uk/ghost-cam.htm">http://www.affiliate-exchange.co.uk/ghost-cam.htm</A> or <A href="http://www.sextoytesters.co.uk/halloween/sexy-halloween.html">http://www.sextoytesters.co.uk/halloween/sexy-halloween.html</A> Thanks!</P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>