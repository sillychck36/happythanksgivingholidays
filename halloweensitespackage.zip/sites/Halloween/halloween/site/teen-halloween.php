<html>
<head>
<title><? include('title.php') ?> :: Chiller- Diller Halloween Games</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Chiller- Diller Halloween Games&nbsp;&nbsp;</H1><FONT size=-1> by Mitch Johnson</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Chill out the curiosity of your guests with some exciting games. Take a tip in this article about some of the most chiller-diller games for your party. <P>"Bluebeard's Den" is a good chiller-diller. Prepare for it by hanging an old sheet across one end of an adjoining room. Cut four holes in it big enough to admit a head. Just around and below each of these slits smear the sheet with red paint or some kind of red coloring. Catsup will do. Beforehand arrange with one of the fellows to play Bluebeard and ask one of the girls to pose as his first be-headed wife. Have powder or flour and a big puff handy so that she may powder her face heavily and quickly. At the appointed time the girl gets behind the sheet, thrusts her head through one of the holes and lets her head hang in a grotesque position. <P>Dim the lights and call in another girl. As Bluebeard swings his blade or shoots his cap gun accompanied by screams from the two girls, the second girl thrusts her head through a hole in the sheet. Repeat the process with a third and fourth girl. When the heads of the four beheaded wives are in place bring the guests, two at a time, from the other room to view the remains. As Bluebeard goes through the motion of showing how he killed each one, the heads moan and scream. This screaming and the report of the cap pistol excite the curiosity of the guests in the adjoining room who are anxiously awaiting their turn to visit Bluebeard's den. <P>No Halloween party is complete without a fortunetelling stunt. Beforehand have one of the girls prepared to be your gypsy fortuneteller. Under the umbrella canopy mentioned earlier you can make a realistic-looking fire by laying a few sticks across orange tissue paper with flashlights concealed underneath. Burning incense gives the effect of steam issuing forth. Instruct the fortuneteller to question each one about his last dream. She can interpret these dreams according to the following meanings. If you pick a clever gypsy she can also use her imagination and her knowledge of the client to make the fortunes particularly apt. Some common interpretations of dreams are: Snakes - deceitful enemies Lightning - beware of accidents Falling - beware of money losses, hard times Crying - joy Sunset - love affair Fog - end of your troubles is coming Writing - will receive an important letter Laughing - love or business disappointment Suffering - wealth Flames - gossip Black cat or crows - bad news Riding on train - visitors Hungry - plenty Fighting - success in love, prosperity Strange faces - travel Tell the crowd its bad luck to follow the leader so you'll play "Contraries." Choose a leader who picks his victim. The victim is to do the opposite of what the leader does. Both are provided with chairs and hats. When the leader stands the victim sits. When the leader puts on his hat the victim takes his off. They should act simultaneously. It is almost impossible to do the opposite while watching the leader, much to the enjoyment of the crowd. After a bit let the victim be the leader and choose some smarty who has laughed long and hard, to be his victim. It's a good game. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Tuna-fish salad tucked into sandwich buns and cheeseburgers are great favorites with teen-agers. Top this off with plenty of cokes or root beer. With some Dixie cups and plenty of mints and nuts the refreshment problem is easily solved. Serve these refreshments buffet style and your friends can squat around the fireplace as they eat. Someone will be sure to tell a blood-curdling ghost story. <P>Try this superstitious party -it's a gang get-together that's really fun. The Bluebeard's Den is also a top of all game, never miss out.<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Mitch Johnson is a regular writer for <A href="http://www.kids-games-n-crafts.com"><A href="http://www.kids-games-n-crafts.com/">http://www.kids-games-n-crafts.com/</A></A> , <A href="http://www.mycostumeshub.info"><A href="http://www.mycostumeshub.info/">http://www.mycostumeshub.info/</A></A> , <A href="http://www.goodbudgetholiday.info/"><A href="http://www.goodbudgetholiday.info/">http://www.goodbudgetholiday.info/</A></A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>