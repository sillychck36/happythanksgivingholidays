<html>
<head>
<title><? include('title.php') ?> :: Halloween Past And Present</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Halloween Past And Present&nbsp;&nbsp;</H1><FONT size=-1> by Mike Eggert</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Did you ever wonder why and where Halloween began? I myself have often thought, what a fun way for kids to get some candy, and at the same time enjoy being some other thing or person if only for a few hours. Going trick or treating was the highlight of the evening. The real truth of Halloween goes back over 2000 years and was not for fun but to bring back the dead once each year on Oct. 31st. <P>The Celtic tribes of Ireland thought on the night of Oct 31st the spirit of the dead would be allowed to come back into the world of the living. And being afraid of the spirits, they dressed up in disguise to try and fool the spirits into thinking they were not living things. <P>Most would wear old clothes and disguise their face with ashes or berry juice, or anything that was available to keep the spirits of the dead away. Over the many years Halloween has changed a great deal but we still use the same reason for dressing up in disguise. To fool the people as to whom we are and, instead of spirits we expect candy in return for not playing a trick on our neighbors. <P>As far as Halloween costumes go, today we may see lots of Batman costumes, or Little Red Riding Hood costumes, as well as many of the popular TV characters of today. There are even baby costumes/infant costumes, and toddler costumes available that will be sure to bring you many years of joy just looking at the pictures of that first Halloween. There are even dog Halloween costumes available that are always great for a laugh. It is yet to be seen as to what the most popular Halloween costume will be this year, but you can never go wrong with something traditional <P>Regardless of the beginning or, to what Halloween has evolved into, it still is a great day and night for our kids to enjoy. Once thought of as the only way to enjoy Halloween, trick or treating seems to be on the way out in most areas today. Although this does seem to be what is happening, trick or treating is still done on a limited base in many areas across the country. Many Malls now offer and encourage kids of all ages to come and trick or treat in a safe and enjoyable environment. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Another way to have a safe Halloween is to entertain your little friends and Goblins with a Halloween party at home. It is important to make a list of friends and family members you want to invite. Plan out a list of games, and contests to keep everyone entertained. You will also need several different kinds of treats for all who come to your party. Maybe you could offer a prize for the best costume. Be sure to decorate with many different Halloween decorations, maybe a few really spooky ones which always create a lot of interest when friends arrive. Keep things as simple as possible so all who attend will understand and enjoy your party. <P>One great game idea for everyone to play at your Halloween party is called "who's the mummy". Divide into pairs give each pair a roll of toilet paper. With one child wrapping and the other child being the Mummy, whoever wraps and uses the full roll of paper fastest is the winner, and receives a treat of your choosing. There are many other games, and I'm sure you will be able to come up with others. <P>As far as trick or treating being a thing of the past, things may not be what you and I remember but our children can still build Halloween memories of their own to someday tell their children.<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>For great <A href="http://halloween.factslink.com">Halloween costume</A> ideas, as well as halloween party planning ideas and more, visit <A href="http://halloween.factslink.com"><A href="http://halloween.factslink.com">http://halloween.factslink.com</A></A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>