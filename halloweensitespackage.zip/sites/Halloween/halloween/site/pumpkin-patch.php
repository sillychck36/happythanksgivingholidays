<html>
<head>
<title><? include('title.php') ?> :: Plan A Halloween Party They'll Never Forget!</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Plan A Halloween Party They'll Never Forget!&nbsp;&nbsp;</H1><FONT size=-1> by Jolanda Garcia</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Have you noticed that Halloween isn't just for kids anymore? It can be a great night for the whole family and particularly if you want an alternative to trick-or-treating. Throwing a Halloween Party is a sure fire way to get both adults and kids excited about Halloween. <P>Halloween party invitations are very important. They are the best way to get your guests excited about the party. Send out some great hand made Halloween party invitations, it will get the kids involved, and you can be sure your party will stick in people's minds. Two weeks in advance is the best time to send them. Let them know there will be prizes for the best costume or scariest pumpkin (more about this later *) <P>- Create a cute ghost card using your kid's footprint. Use some black construction paper and fold it in half. Have your child dip his/her foot into white paint and stamp the card with the footprint. Let your cards try. With a black marker a face to your ghost. Write a message with a gold pen inside your card. <P>- Use some of our printable Halloween invitationsand write your message with a shaky hand, then wrap it in a little cob webbing and enclose little black plastic spiders for extra creepiness. <P>Create the spooky ambiance Halloween is famous for. Hairy spiders in webs in ceilings and corners is the classic but here are some other decorating tips: <P>- Cover tables with black table cloths and decorate with pumpkin cutouts and pumpkin garlands (you can get a pattern to make it yourself) Cover sofas and chairs with white sheets. <P>- Light essential passageways to the toilets or the bar with inexpensive rope lights but try to keep general lighting to a minimum, substituting black or red light bulbs. <P>- Have a pumpkin contest (announcing it in your invitation). * Ask your guests to bring their carved pumpkins to the party and you will have some of the best decorations delivered to your door. <P>- Make a pumpkin patch. Put some boxes on a table to get different heights for display, draping dark fabric over them. Add some real vines of leaves or green ribbons for contrast and of course use tea lights to illuminate. This could also be a good place for your snacks. <P>- Roll up orange napkins with black cutlery inside placing it inside a bat napkin holder. <P>- Place rows of tombstones with the names of your guests leading up to your door. Use decorated cardboard or cereal boxes. <P>- You can also hang Halloween lights around your front door and use a fog machine to welcome your guests (available at party rental stores) <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Games and Activities can really make all the difference and they encourage people to mix. Don't forget to have lots of prizes on hand. <P>- Create a Halloween photo backdrop for everyone to get a picture taken. <P>- Have an area where kids can create their own frame for their photo. <P>- Have a dance contest to the Monster Mash song. <P>- Have a Halloween Lotto giving out prizes of miniature candy bars or party favors. <P>- Rent Halloween videos for later in the evening. <P>When it comes to food and refreshments, it's hard to know where to start. Serving chips and dips in black plastic cauldrons or floating a rubber hand in the punch bowl are just the beginning. Visit <A href="http://www.HalloweenPartyBox.com">www.HalloweenPartyBox.com</A> for great Halloween resources. <P>Halloween isn't just ghosts, witches and monsters or about candy or costumes. Halloween is a perfect time for spending time with family and friends. Having a Halloween party offers plenty of easy and interesting decorating projects and activities for kids as well as for adults.<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Jolanda Garcia is a former teacher and educational content designer and runs several arts and crafts websites. Visit her websites at: <A href="http://www.kidssoup.com/"><A href="http://www.KidsSoup.com">http://www.KidsSoup.com</A></A> and <A href="http://www.halloweenpartybox.com/"><A href="http://www.HalloweenPartyBox.com">http://www.HalloweenPartyBox.com</A></A></P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>