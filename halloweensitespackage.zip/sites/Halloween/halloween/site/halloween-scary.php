<html>
<head>
<title><? include('title.php') ?> :: Top Ten Horror Movies of All Time</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Top Ten Horror Movies of All Time&nbsp;&nbsp;</H1><FONT size=-1> by Rosanne O'Malley</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Top Ten Horror Movies of All Time <P>Halloween is coming and my thoughts inevitably turn to ghosts and goblins and things that go bump in the night. Family tradition around my house dictates, that along with plenty of snack-sized candy bars, the gruesome graveyard scene I set up in my bay window and the haunted house complete with ghosts and bats that has pride of place on our living room mantel, we have plenty of horror movies to watch to send chills and thrills down our spines on All Hallows Eve. Of course, I have my favorites, some of which don't have ghosts, goblins or evil spirits, but are extremely full of the fright factor. I choose these movies because the creepy-crawly feeling engendered by them lingered long after the ending credits rolled. So, for what it's worth, here is my list of the top ten horror movies of all time. <P>10. Jaws ( 1975). Directed by Steven Spielberg and stars Roy Scheider, Robert Shaw and Richard Dreyfus, Jaws is about a great white shark that menaces the island community of Amity during the height of the summer tourist season. Memorable scenes for me include the one where the female swimmers head bobs up in the water while the shark tries to pull her under and the one where Quaint (Robert Shaw) gets eaten. <P>9. Alien (1979). Directed by Ridley Scott and stars Sigourney Weaver, Tom Skerrit and John Hurt. An alien life form, a xenomorph, picks off the crew of the space ship Nostromo one by one, until it, in turn, is destroyed by the sole surviving member. Can anyone ever forget the scene where the alien bursts out of Kane's chest? <P>8. The Birds (1963). Alfred Hitchcock, master of the horror movie genre, directed this film about birds attacking the town of Bodega Bay. Starring Tipi Hedren, Rod Taylor and Suzanne Phleshette, it forever changed the way I looked at birds. <P>7. The Shining (1980). Directed by Stanley Kubrick and based on a Stephen King novel, this film stars Jack Nicholson and Shelly Duval. It is the story of an alcoholic's descent into madness and the violence he perpetrates against his family while they are snowbound in an isolated inn. Memorable scene: Jack Torrance grinning maniacally, looking through the door he hacked open with an axe, crying, "Here's Johnny!" <P>6. Scream (1996). Wes Craven directed this film that revitalized the slasher film genre. Starring Neve Campbell, David Arquette and Courtney Cox, it involves a series of murders, connected to a young girl on the anniversary of her mother's death. It is notable for Randy's Rules on how to survive a horror movie that include don't have sex, don't do drugs and don't say that you'll be right back. <P>5. Halloween (1978). John Carpenter, another master of the horror film, directed this one set in the fictional town of Haddonfield. Starring Donald Pleasance, Jamie Lee Curtis and Nick Castle, it centers around a young girl being stalked by her psychotic brother. Of course, plenty of people are slashed along the way. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>4. The Nightmare on Elm Street (1984). Another Wes Craven directed film, it stars Robert Englund, Heather Lagencamp, and, in his first movie role, Johnny Depp. It focuses on the line between dreams and reality as Elm Street children are killed by Freddy Krueger, a figure that appears in their nightmares. <P>3. The Exorcist (1973). This film, directed by William Friedkin, stars Ellen Burstyn, Max Von Sydow and Linda Blair. It centers around a priest's attempts to exorcise the devil from a young girl. Memorable scenes include Regan's vomiting "pea soup" and her head turning around completely while she is possessed by the devil. Really, really scary film. <P>2. The Haunting (1963). Directed by Robert Wise and starring Julie Harris, Claire Bloom and Russ Tamblyn, this film follows the events that take place at an isolated mansion when five people go there one weekend to explore alleged supernatural occurrences. No gore in this film, just great acting, a creepy score and a spooky setting, Hill House! <P>1. Psycho (1960). This film, directed by Alfred Hitchcock, stars Anthony Perkins and Janet Leigh. The shower scene, the Bates Motel, Norman Bates and Mother. What more need be said? This film sets the standard for horror movies to this day. <P>If you would like to view more movies like these, <A href="http://rosomalley.mp3center.hop.clickbank.net" target=_top>Click Here!</A><center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>None</P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>