<html>
<head>
<title><? include('title.php') ?> :: Halloween Activities for Young Children</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FF0000;
}
a:visited {
	color: #FF0000;
}
a:hover {
	color: #FDF100;
}
a:active {
	color: #FF0000;
}
-->
</style></head>
<body>
<!-- ImageReady Slices (hallo-adsense.psd) -->
<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF6600">
  <tr>
    <td><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/hallo-adsense_01.jpg" width="780" height="109" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7D7D7"><p align="center">

		<br>
          <H1>Halloween Activities for Young Children&nbsp;&nbsp;</H1><FONT size=-1> by Jamie Jefferson</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Celebrate the annual Fright Night with these sixteen fun (and not so scary) ideas, especially for young children. <P>1. Try your hand at face painting, or allow your children to paint their own faces with washable face paints. <P>2. Make your own goodie bags. Set out some brown paper bags with the standard art supplies or embellish an old pillowcase with fabric paints. You can even spring for blank canvas baggies from your local discount store or craft store without spending a lot. <P>3. Tie dye some T shirts or socks using orange and black fabric dyes. <P>4. Make ghosts. Fold a piece of black construction paper in half and let your child squirt white paint inside. Squish the paint, let dry, then embellish the white ghost with paints, markers and other craft supplies. <P>5. Watch a Halloween movie. Make popcorn, cuddle up together in blankets, and take in some spooky cinematic sights. Harry Potter, Dracula, or Ghostbusters are great choices. For younger children, choose Heffalump Halloween, starring Winnie the Pooh or The Adventures of Ichabod and Mr. Toad by Disney Classics. <P>6. Eat creepy cuisine. Cut sandwiches or tortillas into Halloween shapes with cookie cutters. Create a ghoulish look with almost anything by mixing in a little green or red food coloring. <P>7. Play "Guess How Many Pumpkin Seeds." Each family member or party guest gets to take turns guessing how many pumpkin seeds are in a jar. The winner gets a prize. <P>8. Go apple bobbing. Fill a bucket or tub with water and apples and see how many apples each contestant can snag. <P>9. Make masks. Set out the art supplies and see who can make the scariest mask with a paper plate, construction paper, yarn, and markers or paints. <P>10. Create a family costume. Come up with a costume theme that the whole family can participate in. One year, we were all Star Wars characters. Maybe you will all be people from the Wild West or fuzzy forest animals. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>11. Have a pumpkin seed spitting contest. <P>12. Roast pumpkin seeds. Clean the pumpkin seeds and toss them in just enough melted butter to lightly cover the seeds. (One tablespoon of butter is generally enough for the seeds from a medium sized pumpkin.) Salt the seeds, then spread them on a baking sheet in a single layer. Bake at 250 degrees until golden brown, stirring occasionally. <P>13. Play Pin the Tail on the Black Cat (or Pin the Nose on the Pumpkin.) Any variation of Pin the Tail on the Donkey is fun for young kids. <P>14. Make a Scare Tape. Record you and your family members making spooky sounds. All you need is a tape recorder and a little imagination. Include footsteps, slamming doors, creepy howling werewolves, and crazy cackles. Play the tape from your front porch on Halloween. <P>15. Give each child an inexpensive disposable camera for the big night. This is a fun way to see what Halloween looks like from their perspective. I love to give my kids a blank journal and let them tell the story of memorable events, such as Halloween. This is a great tradition and really helps them to tell their personal stories, which they will cherish for many Halloweens to come. <P>16. Once Halloween is over, make sure to shop the post Halloween sales for fun additions to your dress up closet, which your young children are sure to enjoy year round. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>Happy haunting!<BR> <P><B>About the Author</B></P> <P>Jamie Jefferson is a frequent contributor to Momscape.com. Visit today for the latest online <A href="http://www.momscape.com/coupon-codes">Coupon Codes</A> including <A href="http://www.momscape.com/coupon-codes/dick-blick.htm">Dick Blick Coupons</A> and <A href="http://www.momscape.com/coupon-codes/overstock.htm">Overstock Coupons</A>.</P><br>
            <strong><br>
           <center><a href="index.php">SITE MAP</a></center></strong>          <br>
              </p>
          </td>
      </tr>
      <tr>
        <td><img src="images/hallo-adsense_03.jpg" width="780" height="88" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<!-- End ImageReady Slices -->
</body>
</html>