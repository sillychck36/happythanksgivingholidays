Included is a blank jpg if you do not have Photoshop to edit the included psd file

The site is very easy to configure. There are 5 files you can edit.

You do not have to edit anything but the 3 adsense files, but you can extend the site easy.

The files you can edit are: ad1.php ad2.php ad3.php title.php url.php

ADSENSE FILES
ad1.php ad2.php ad3.php 

These 3 files control the adsense on the site, just edit the files and insert your complete adsense code
google_ad_client  = "";
You would add your adsense client code in the quotes starting with the ca-pub-xxxxxx
google_ad_client  = "ca-pub-xxxxxxx";

Then you are all set for adsense, next you can edit the title.php  
This is your site's title, just edit the file and put the sites title in it, do not hit enter it should all be on one line.

We have created a xml rss feed for the site. Just edit the url.php  to reflect where you installed the site to,
do not hit enter after you insert the url.

If you uploaded the site to

www.mydomain.com

You would just edit url.php and put http://www.mydomain.com   (notice no trailing slash / )

If you installed it to a sub directory ie thanksgiving

www.mysite.com/thanksgiving/

Then you would edit url.php and put http://www.mydomain.com/thanksgiving  (again notice no trailing slash  / )

Now you can submite your feed to rss directories ie http://www.mydomain.com/feed.php

