<html>
<head>
<title><? include('title.php') ?> :: Thanksgiving Holiday Crafts:- Wonderful Decorations Kids Can Make</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>Thanksgiving Holiday Crafts:- Wonderful Decorations Kids Can Make&nbsp;&nbsp;</H1><FONT size=-1> by Tri Bros Broda</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Thanksgiving is a wonderful holiday! What a spiritual renewal to take a day to reflect over the past year about just how good God has been to you and your family, to give you harvest and shelter, health and hope. To get the most out of this joyous occasion, make some holiday crafts with your children. These days, Thanksgiving often gets squeezed out by Hallowe'en's spooky decorations and the lights and gala of Christmas. With the following holiday crafts, your home can be decorated for this quieter but important celebration. <P>Turkeys are a natural choice for decorations. A familiar project at this time of year is for a child to trace around her hand and make the resulting drawing into a turkey. The thumb is the head and the fingers are the tail feathers all displayed. While many of the turkeys that are raised for food are now the domestic white variety, the turkeys eaten by the Pilgrims at the first Thanksgiving were the wild brown ones. The tail feathers on a wild turkey are brown, but they are iridescent. Catching light and appearing to be multi-colored. This is why children color the tail feathers in bright colors. <P>The turkey's head has a wattle under the beak. This is a vertical flap of loose skin that is red colored. Be sure to draw this in order to make the hand turkey look like a turkey. Add skinny legs and bird feet. When done, the children can cut out the turkeys and hang them on the wall. It's really cute to make a whole flock of these turkeys in the sizes of all the hands in the family. The little hand shapes are particularly sweet. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Another nice turkey decoration to make when making Thanksgiving holiday crafts is a turkey door decoration. Make a brown construction paper body and head of a turkey. Now make a large number of colored feather shapes. Each family member writes on a feather something he or she is thankful for before attaching as part of the turkey's tail. Repeat until all the feathers are used, and hang the turkey on the front door to greet visitors with a message of gratitude. Make a sign to accompany the turkey that says "Give thanks to the Lord for He is good!" or simply "Be thankful!" or "We're thankful for you!" or whatever you like. <P>Children love making construction paper chains. To further decorate the house for Thanksgiving, let them make a paper chain in fall colors as one of their holiday crafts. Using 9 by 12 inch construction paper, cut the paper in half across the long side and cut the halves into one inch thick six inch long strips. Use a stapler to attach the ends of the strip into a circle. Loop the next strip into the circle and staple it. Continue the process alternating colors of brown, red, yellow, and orange. When the chains are long, you can drap them along the ceiling or stair rail. If you don't make the door turkey, the children can write something they're thankful for on each strip of paper before adding it to the chain. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>Thanksgiving is too nice a holiday to let the other more commercial holidays crowd it out. By making holiday crafts to decorate the home for Thanksgiving, you can keep this day special, too. The extended family, aunts, uncles, grandparents, etc., will be pleased to see the holiday crafts the young ones have made to decorate the house and make it cheerful for their visit.<BR> <P><B>About the Author</B></P> <P>If you enjoy working with your hands, make arts and crafts as a hobby and would like to turn it into a business than "<A href="http://www.waho-biz.com/craft-business.html">Craft Business Pack</A>" or, "<A href="http://www.assembly-jobs.com">Craft &amp; Assembly Jobs Package</A>" will take you by the hand and walks you through the steps to earn money.</P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>