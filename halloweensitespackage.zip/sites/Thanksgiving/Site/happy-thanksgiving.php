<html>
<head>
<title><? include('title.php') ?> :: Thanksgiving Gift Ideas</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><h1>Thanksgiving Gift Ideas</h1><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<br><p>Being surrounded by loved ones and good things is a gift in itself, without which no occasion would make much sense to the world. But on Thanksgiving, people celebrate these gifts bestowed on them with more meaning and warmth. Thanksgiving is a time to acknowledge the blessings which God has gracefully showered upon us each passing day. Traditionally, Thanksgiving was a harvest festival and the people gathered to express their gratitude to the Almighty for the bountiful Autumn harvest. But now, the spirit of thankfulness has spread to all aspects of our lives that make it richer and more prosperous. We say  thanks  for the most treasured gifts in our lives our family, friends and loved one. So this Thanksgiving Day, you can express your appreciation for these wonderful people with some Thanksgiving gift. Take a leaf from some of the following Thanksgiving gift ideas listed for you.</p><p><strong>Thanksgiving gift baskets:</strong></p><p>A Thanksgiving gift basket can be an ideal gift for a close relative, a dear pal or your sweetheart. For a friend you can get a gift basket with goodies like pumpkin-flavored iced cookies, leaf-shaped milk chocolates wrapped in Autumn-colored foil, mini tea cakes and brownie bars. For your siblings  or your parents  homes, you can get a wicker cornucopia basket full of their favorite things. Cookies, cakes, scented candles, spa kits and the list goes on. The colors and aromas of fall and the taste of Thanksgiving that these Thanksgiving gift baskets carry, are sure to convey the appreciation you feel for the receivers.</p><p><strong>Thanksgiving flowers:</strong></p><p>One of the sweetest Thanksgiving gift ideas is to gift flowers ! Flowers that reflect the colors of fall make ideal Thanksgiving gifts. A cornucopia flower arrangement can be a lovely Thanksgiving gift for any household as this is a traditional symbol of the occasion. Seasonal burnt orange, fiery red, yellow, and green blooms create an ambience of warmth and the soft blooms of the Asiatic Lilies, Red Rover Chrysanthemums, Marigolds, Spray Roses and Carnations make the sight of the arrangement in the cornucopia engaging. A simple bronze wicker basket of fresh fall daisies or an assortment of Autumn flowers can be apt Thanksgiving gifts for your frie neighbors, or colleagues. Flowers will carry your Thanksgiving prayer for them as also wish them a happy thanksgiving. Thanksgiving flowers even work wonders if you re far away from your loved ones and want to let them know how much you miss them.</p><p><strong>Inflatable toys:</strong></p><p>Thanksgiving gift ideas are galore; but how to make your gift stand out this year ? Thanksgiving won t feel like Thanksgiving without a big roasted turkey on the dinner table, would it ? The turkey over the years has become one of the most recognized symbols of Thanksgiving and on this Thanksgiving you can get an inflatable turkey or an inflatable scarecrow (another symbol of Thanksgiving) for a neighbor or a friend to have them gaping at your innovatively amusing Thanksgiving gift. These make good outdoor decorations, befitting the festival ambience, and will surely be fun toys for very young kids in any home !</p><div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<p><strong>Thanksgiving crafts:</strong></p><p>An eye-catching seasonal wreath of dried poppy pods and pomegranates accented with red oak and green lemon leaves and grass and a lot more could be a lovely Thanksgiving gift for an office colleague, a neighbor or your teacher. A box of miniature gourd shaped Autumn scented candles is again a very good Thanksgiving gift idea for anyone you hold close. A cornucopia of blown glass with faux fruits and gourds piled high can be a lovely gift for your boss. These skillfully crafted Thanksgiving gifts will be anyone s joy and will stay with the receivers for many years to come.</p><p><strong>Home accessories:</strong></p><p>A central feature of Thanksgiving is the Thanksgiving dinner. It is the harvest feast arranged to honor God for the food that He provides. Some exquisite china or some lace for the dining table can be great ideas and ideal Thanksgiving gifts on this occasion to wish a happy Thanksgiving. You can buy yourself or your parents a Turkey preparation kit for the occasion and make preparing dinner this Thanksgiving an easy affair. A thoughtful home accessory can be the ideal Thanksgiving gift for this family festival.</p><center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<p>There are a lot of Thanksgiving books, Thanksgiving movies and music collections in addition to these, that make good Thanksgiving gifts too. So every Thanksgiving, you have a big array of<strong> </strong>Thanksgiving gifts to choose from. Thanksgiving gifts express your thankfulness for someone. So send a gift and make someone feel special in the spirit of November 24, the Thanksgiving Day. All you need to do is make sure that your gifts or cards tell your friends and family how blessed you feel and thankful you are to have them in your life.</p><div><table cellpadding="0" cellspacing="0" border="0"><tr><td valign="top"><div class="sig"><p>Sean Carter writes on holidays, <a target="_new" href="http://www.123greetings.com/events/thanksgiving">thanksgiving</a> and celebrations around the world. He also writes on family, relationships,womens issues  <a target="_new" href="http://www.123greetings.com/birthday">birthdays</a>, inspiration, religion, love and friendship. He is a writer with special interest in ecard industry. He writes for <a target="_new" href="http://www.123greetings.com">123greetings.com</a></p><p>Article Source: <a href="http://ezinearticles.com/?expert=Sean_Carter">http://EzineArticles.com/?expert=Sean_Carter</a></p></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>