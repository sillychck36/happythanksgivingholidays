<html>
<head>
<title><? include('title.php') ?> :: Restaurant Quality Sauces At Home</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>Restaurant Quality Sauces At Home&nbsp;&nbsp;</H1><FONT size=-1> by Bill Long</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>We've all been served great sauces in our favorite restaurants and would love to recreate them in our own kitchens but we are not sauciers. (French term for sauce chef) <P>Professional chefs go to culinary school for years to learn the secrets of making classic French sauces and the more modern sauces derived from them. So what are we supposed to do? <P>Yes, there are some sauces that require strong cooking skills. Making a Hollandaise sauce with butter and egg yolks is difficult because so many things can go wrong but with a little practice and a lot of focus, anyone can make a decent Hollandaise. <P>Mayonnaise is another emulsion sauce that many cooks imagine is too hard or two much work to prepare but nothing could be further from the truth. Mayonnaise is oil, egg, vinegar, condiments and spices. Again, all it takes is some skill with a whisk, the right ingredients and some patience. <P>Then there are the butter sauces that scare a lot of new cooks. When we hear "beurre blanc" sauce we automatically think, "This is going to be hard" but truth is they are easy if you start with well chilled butter, keep the heat low, add butter a little at a time, stay focused and serve immediately. <P>White sauces including Allemande (German sauce), Supreme, and Normande are a little tricky because they all start with a chicken or fish base called veloute and then other ingredients are added to give the sauce its flavor. Veloute is simple a white stock that has been thicken with a white roux. <P>Let's back up for a second. A stock is a flavored broth that has been extracted from meats, fish, or vegetables by cooking them in water slowly for a period of time. A white stock is made with meats, chicken, fish or vegetables that have not been browned and are pale in color. <P>For example, simmering the carcass of a chicken along with some aromatic vegetables can make a white chicken stock but to make a brown chicken stock, you first roast or brown the carcass. <P>A roux is a mixture of flour and fat that is cooked together and used to thicken soups and sauces. Depending on how long you cook the roux will determine if it called a white roux (the lightest), a blond roux or a brown roux. <P>So the veloute, a combination of the white stock, butter and flour, is the base or start to most of the classic white sauces. For sauce allemande you add egg yolks and mushroom cooking liquid. For sauce supreme, heavy cream, mushroom cooking liquid and some more butter. <P>Are they difficult to make at home? Absolutely not! They just take time, patience and focus. The ingredients are readily available whether you make your own homemade stock or purchase a good quality commercial brand. <P>As for tools, all you need is a heavy bottomed saucepan and a whisk. Professional chefs will typically strain their veloute and sauces through a fine strainer called a chinois but it's not absolutely necessary. A common household strainer with small holes will work too. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>When we start talking about brown sauces, here's when many new cooks start to get nervous. Just thinking about making "the gravy" at Thanksgiving gives some cooks the yips so how are they suppose to make a classic brown sauce like bordelaise or chasseur? <P>These sauces are all derived from the same base called demi-glace or some form of meat stock reduction. If you can get your hands on some demi-glace by either making it yourself (very time consuming) or purchasing a good quality product on the market, making any of these classic sauces is not difficult at all. <P>For example, the classic bordelaise sauce is basically shallots, wine, fresh thyme, butter, parsley and demi-glace. Chasseur sauce, also called hunters sauce because it goes well with wild game, is a combination shallots, mushrooms, butter, white wine, sometimes tomatoes and demi-glace. <P>If you go any high-end restaurant's kitchen, you will most likely find some form of demi-glace or other meat stock reduction cooking on the stove. Culinary students are taught first thing about making stocks and their reductions. They spend hours making them day after day because they are the basis for all classic French sauces. <P>This doesn't mean you can't prepare these same sauces at home to serve with your chicken, veal, beef or fish. All it means is you have to find a quality commercial product, know someone in the restaurant business or spend the time to make a batch yourself. <P>A weekend spent preparing a good demi-glace will give you enough to last quite a while. Because these sauce bases freeze so well, you can have rich sauces year round or you can find a classic recipe at <A href="http://www.gatewaygourmet.com/demi_glace.htm"><A href="http://www.gatewaygourmet.com/demi_glace.htm">http://www.gatewaygourmet.com/demi_glace.htm</A></A> to try at home. <P>If you not excited about making it from scratch, there are sources listed at the same site for manufacturers who are making restaurant quality demi-glace for both home users and commercial establishments. <P>Either way, making restaurant quality sauces at home is not as difficult as you might have thought. The myth that only professional chefs with years of experience can prepare classic sauces is not true. With a little practice and the right ingredients, you can be wowing your family and friends at your next dinner party. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>Copyright � 2006 Bill Long, GatewayGourmet.com<BR> <P><B>About the Author</B></P> <P>Bill Long is the administrator of <A href="http://www.gatewaygourmet.com">GatewayGourmet</A>, a website offering resources to new cooks interested in cooking by focusing on sauces and <A href="http://www.gatewaygourmet.com/culinary_schools.htm">culinary schools</A></P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>