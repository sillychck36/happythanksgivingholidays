<html>
<head>
<title><? include('title.php') ?> :: A Deep Frying Guide to Turkey</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>A Deep Frying Guide to Turkey&nbsp;&nbsp;</H1><FONT size=-1> by John Gibb</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Deep frying has been producing tasty food for many years, but one of the new fads to come about with deep frying is cooking a whole turkey this way. Many people are foregoing the oven method at Thanksgiving and going with the deep frying method - and it is producing amazingly delicious results. <P>Obviously, since whole turkeys are so large, you can't cook one in a regular home deep fryer; you need a special turkey fryer to do the job. There are several good turkey fryers on the market today, and most of them have features that make them safe for deep frying such a large food item. Despite the safety features, however, the fact that you need to use a lot of oil and you are deep frying such a heavy food item still makes it a little more dangerous than deep frying smaller food items in a smaller home deep fryer, so following directions to the letter is a definite necessity. And, you should only use the turkey fryer outside. An advantage to deep frying a turkey rather than cooking it in the oven is the length of cooking time; a twelve pound turkey takes only about forty-five minutes to an hour to deep fry, as opposed to about 20 minutes per pound if it is baked in the oven. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>First of all, for safety's sake, you need to purchase a fryer specifically for deep frying turkeys. Many people each year try to rig up their own homemade deep fryers for cooking their turkeys, often with disastrous results. Turkey fryers can cost anywhere from $75 to over $200 dollars, but it is worth it to spend the money if you want safety and a deep fried turkey that turns out right every time. <P>Turkey fryers can come in a few different varieties. There are those that are electric, and those that run on gas - usually propane. What type you use really depends on personal preference. A lot of people swear by the gas fryers for maximum flavor, but other people think that there really is no difference. As long as you buy a good quality turkey fryer and follow all of the directions, you are most likely going to get a delicious finished product. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>Experienced cooks will tell you that one of the secrets to getting a good deep fried turkey is what you put on it before it goes into the fryer. Do some research and you will find a myriad of recipes for turkey rubs, and once again, which one you choose is a matter of personal preference. The bottom line is, though, that if you put a good rub on your turkey before you deep fry it, you're going to get a finished product with better flavor. <BR> <P><B>About the Author</B></P> <P>John Gibb is the owner of <A href="http://www.deepfat-frying-guides.info">deep fat fryer sources</A> , For more information on deep fat fryers check out <A href="http://www.deepfat-frying-guides.info">http://www.deepfat-frying-guides.info</A> </P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>