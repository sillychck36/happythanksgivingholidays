<html>
<head>
<title><? include('title.php') ?> :: Vegetarian Thanksgiving - No Turkeys?</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>Vegetarian Thanksgiving - No Turkeys?&nbsp;&nbsp;</H1><FONT size=-1> by Sean Carter</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>What comes to your mind when you first think of Thanksgiving? The big fat golden-brown turkey? To millions, a Vegetarian Thanksgiving would mean no heaps of turkey meat at their dining table to feast on, but to the turkeys it would mean freedom to LIVE. <P>Thanksgiving is a time for giving thanks to God for blessings received during the year. It is usually a family day, celebrated with joyous reunions, feastings and prayers. Families and friends come together to enjoy the Macey's Thanksgiving Parade and Football. Although it is a major celebration in the United States and Canada, other countries like Japan, South Korea, the Philippines, Laos, Liberia, Puerto Rico, the Virgin Islands, etc also celebrate this joyous holiday. <P>Vegetarian Thanksgiving is a term which has slowly become popular all over, not only with the vegetarians but also among the non vegetarians. Being veg. is a journey, not a destination - even with its back roads, detours and speed bumps. Thanksgiving used to be a vegetarian's worst nightmare, but no longer. More and more vegetarian groups are holding dinners and celebrations, and there are even caterers and food companies specializing in a wide selection of meatless alternatives. <P>The living and the dead! If turkeys were our companions, we would be terribly upset with the death of any one of them; but because they are "food", we are indifferent to their death. Thousands of free-range turkeys are raised in a single warehouse-like structure forced to stand on accumulated fecal waste and breathe in ammonia fumes. These turkeys are then taken to the slaughterhouse through transport containers where they are hung upside down in shackles. There they cry out in fear and pain as they await their own slaughter. Think of how much it hurts when we get a little speck in our eye, and we might understand the degree of suffering that the turkeys are been forced to endure day after day. When left the way God intended turkeys to be, they have a wonderful and close family life. It is not human to deprive them of this gift from God. <P>There is a lot more to explore at a thanksgiving dinner table than just turkeys. Some food items that I can suggest, which I found from some great recipe sites, would be: <P>APPETIZERS/STARTERS <P>Guacamole, a Relish plate of sliced vegetables (Crudit�s) and White wine. <P>MAIN COURSE <P>Vegan Nut Roast � la PeTA Ingredients: 'The roast': Two tablespoons oil or margarine 2 large onions, chopped fine 5 cloves garlic, minced 3 cups raw cashews 1 1/2 cups bread 1 cup soup stock (or water) Salt and pepper 1/2 teaspoon nutmeg 2 tablespoons lemon juice <P>'The stuffing': 3 cups bread cubes, toasted Two tablespoons margarine, melted but not hot 1/2 to 3/4 cup finely-chopped onion 1 cup chopped celery 1/2 teaspoon thyme 1/2 teaspoon marjoram 1/2 teaspoon sage 3 tablespoons parsley, chopped Salt to taste <P>Method: Cook the onion and garlic in the oil or margarine until tender, and remove from the heat. Chop the cashews by hand or in a food processor; cut up the bread as well. Add the cashews and bread to the onion, then add the vegetable stock, salt and pepper, nutmeg, and lemon juice. Put half of this mixture into a small, non-stick loaf pan. Mix together all the ingredients from the second list. Put the mixture on top of the stuff in the loaf pan, and add the rest of the first mixture so that there are three layers of food in the pan. Place the pan on a baking sheet or in a larger loaf pan, and bake at 400 degrees F for half an hour. The top should be browned. Let the roast cool for a few minutes, then turn the pan over and serve the roast on a plate. Serve with gravy if desired, keeping in mind that it is a very rich dish. <P>Notes: The roast will take about an hour to prepare. This recipe makes roughly six servings. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Other main courses items could be: Home-made bread, Salad, Steamed carrots and green beans, Mashed potatoes, rolls, Bread stuffing, Red wine, Vegan Bisquits, Vegan Nut Roast with Stuffing � la PeTA, Vegan Gravy and Simple Cranberry Sauce. <P>DESERT <P>Vegan Pumpkin Pie Ingredients: 1 350-g box of silken firm tofu, drained 1 heaping cup of cooked or canned pumpkin 1 to 1 1/4 cups brown or golden sugar, not packed tight dash salt 4 teaspoons blended "pumpkin pie spice" OR: 1 teaspoons cinnamon 1/2 teaspoon ground dry ginger 1/2 teaspoon ground cloves 1/2 teaspoon allspice 1 teaspoons nutmeg 1 pie crust <P>Method: Heat oven to 375 degrees F. Blend the tofu in a food processor or with a blender until smooth and cream-like, for about four minutes. Stop the machine every once in a while to scrape large pieces of tofu down into the machine's blades. Add the cooked pumpkin and blend some more, again stopping the machine and scraping the mixture down. The result should be a light orange-colored paste with no lumps of tofu. Put the paste into a large mixing bowl and add the sugar, salt, and spices. Mix well and spoon it into the pie crust; decorate with cheerful shapes of leftover crust, if desired. Bake 30 to 40 minutes or until the crusts are dark brown. Serve warm or chilled, plain or topped with whipped cream or ice cream. <P>Notes: This pie takes about two hours to prepare. A single good-sized sugar pie pumpkin will usually yield enough material for two pies: the recipe doubles easily. The pie refrigerates and freezes well. <P>Other Desert items could be: hot cocoa, Vegan Pumpkin Pie and Butter Tarts. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>You can wish your friends and family a Vegetarian Thanksgiving with a simple Ecard from sites such as 123Greetings.com<BR> <P><B>About the Author</B></P> <P>Sean Carter writes on holidays,<A href="http://www.123greetings.com/events/thanksgiving/"> Thanksgiving</A> and events around the world. He also writes on family, relationships,<A href="http://www.123greetings.com/events/christmas">Christmas</A>, inspiration, religion, love and friendship. He is a writer with special interest in ecard industry. He writes for <A href="http://www.123greetings.com">123greetings.com</A></P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>