<html>
<head>
<title><? include('title.php') ?> :: How to Host a Great Dinner Party in Seven Easy Steps</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>How to Host a Great Dinner Party in Seven Easy Steps&nbsp;&nbsp;</H1><FONT size=-1> by Evelyn Cole</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Copyright 2006 Cole's Poetic License <P>Remember that message about oxygen masks on airplanes? You must attach your mask first before helping anyone else. The same goes for giving a great dinner party. Give to yourself first. The rest comes easy. <P>Here are seven essential steps: <P>1. Recall some of the parties you loved, whether or not you or your family hosted them. Think back as far as you can remember. <P>Social affairs operate on a subconscious level predominantly. When you accept that fact and look at your own subconscious feelings, you can plan your own social pleasures. And, you can better understand your friends and family. Our social memories are stored in our subconscious minds. That is why this step is so important. <P>(Once I had so many guests for Thanksgiving I had to cook two turkeys and set up long tables in the living room. I carried in one turkey and set it on the end nearest the kitchen. My daughter carried the other to the end table near the fireplace. As she leaned forward to set it on the table, the turkey slid off the platter onto the table. A male guest uncrossed his arm in that umpire gesture and hissed, "Safe!" The rest of the day was sheer fun.) <P>2. Spend ten minutes writing about one dinner party you particularly enjoyed. Be specific. This step helps you plan. <P>(I remember a dinner for eight where everyone listened to the one speaking and everyone took turns. Without competition for attention, relaxed witticism and laughter prevailed.) <P>3. Recall dinner parties you loathed as far back as you can. <P>4. Spend ten minutes describing one. This step helps you know what to avoid. <P>(Tension at the table. My sister-in-law barks at my brother because he forgot to hold her chair for her when she sat. My other brother makes fun of that idea. His wife kicks him under the table, audibly. I laugh and my mother cries.) <P>5. Make a list of what is most important to you when you host a dinner party. Is it the food? Wine? Serving dishes? Choice of guests? Conversation? Music? Prioritize the list. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>(I start with the food that I like best and include choices for finicky guests) <P>6. List a few situations or conditions that may embarrass you during your party and deal with each beforehand. <P>For example, if one of your friends gets drunk, <P>if your sister talks too much and bores the other guests, <P>if conversations splinter in loud groups of two, <P>if your main dish burns, etc. Plan your party. Become a movie director building the "right" scene. Have a dinner bell handy to capture attention when necessary. <P>7. Social anxiety prevents pleasure. Here are some suggestions to counteract potential problems: <P>A. Demand that guests arrive by a specific time. <P>B. Invite people you enjoy. Don't invite anyone else. <P>C. Give to those most anxious some pre-planned serving tasks. <P>D. Try this or similar exercise: Even if the guests know each other well, ask each one to tell the rest three "facts" about himself. Two will be true, the third a lie. Guests will then guess which is the lie. Given them three minutes to plan. You direct. Remember, this is your movie. <P>E. All courses should be prepared in advance. <P>You can have a lot of fun at your own dinner party if you consider yourself first. When you give to yourself first, you become wonderfully generous. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>And don't forget to breathe. <P>Cheers, <P>Evy <BR> <P><B>About the Author</B></P> <P>� Evelyn Cole, MA, MFA, The Whole-mind Writer, <A href="http://www.write-for-wealth.com">http://www.write-for-wealth.com</A> evycole@hughes.net Cole's chief aim in life is to convince everyone to understand the power of the subconscious mind and synchronize it with goals of the conscious mind. </P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>