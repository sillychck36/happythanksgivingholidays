<script type="text/javascript"><!--
google_ad_client  = "";
google_ad_width   = 120;
google_ad_height  = 240;
google_ad_format  = "120x240_as";
google_ad_type    = "text";
google_color_border = "D7F8C9";
google_color_bg = "D7F8C9";
google_color_link = "0000CC";
google_color_text = "000000";
google_color_url = "000000";
//--></script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>