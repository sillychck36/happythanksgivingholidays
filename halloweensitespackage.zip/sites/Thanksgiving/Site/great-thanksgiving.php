<html>
<head>
<title><? include('title.php') ?> :: Thanksgiving Flower Arrangements</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><h1>Thanksgiving Flower Arrangements</h1><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<br><p>While your own personality will ultimately determine what will go into your Thanksgiving flower arrangement, we've pulled together some ideas from getting started to applying the finishing touches.</p><p>Thanksgiving is a traditional autumn holiday with a rustic, earthy theme and your flower arrangement can easily incorporate this by the colours and materials you choose. Autumn is the season of deep, warm colours reminding us of ripe fruits and vegetables, and of the leaves turning on the trees before falling. For your main items choose flowers and accessories in a variety of reds, oranges, yellows, coppers and browns. A touch of green or blue is a great complement and will bring out the warm colours beautifully!</p><p>Great seasonal flowers are chrysanthemums, asters, pansies and even sunflowers. Mums and asters can be used in medium to large arrangements, possibly with a handful of small roses and stalks of wheat or barley as accents. If you have a garden, take a stroll through it to see what is still thriving - it could end up being the main attraction in your arrangement!</p><p>If you want a handful of smaller arrangements, pansies in old mason jars can add a bit of freshness throughout your home, whether they are placed in washrooms to greet guests, or scattered among buffet dishes on the dining room table. To dress them up, simply tie some ribbon around the jar, preferably ribbon with wire edges that can be shaped to your liking.</p><div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<p>Once you've determined which flowers you want to use, you can figure out what container you're going to arrange them in. Possibilities include vases of varying sizes, mason jars, water pitchers, metal watering cans, and terra cotta pots (with a smaller vase or glass inside to hold the flowers and water).</p><p>Once your arrangement is created, don't forget to tie all of your colours together with some richly coloured ribbon, raffia, or decorative stones.</p><center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<p>Have fun creating your flower arrangement! There are no right or wrong ways as long as you let your creativity show. You'll know when the arrangement feels and looks right so follow your instinct and have a great Thanksgiving!</p><div><table cellpadding="0" cellspacing="0" border="0"><tr><td valign="top"><div class="sig"><p><a target="_New" href="http://www.decoratefor.com/fall_decorations/index.asp" > fall decoration ideas </a> - think decorating is only for the spring and summertime? Think again! Find all sorts of <a target="_New" href="http://www.decoratefor.com/fall_decorations/index.asp"> fall decorating ideas </a> today.</p><p>Article Source: <a href="http://ezinearticles.com/?expert=Stephanie_Smith">http://EzineArticles.com/?expert=Stephanie_Smith</a></p></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>