<html>
<head>
<title><? include('title.php') ?> :: </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><b>Thanksgiving Ideas </b><br>
        <li><a href='about-thanksgiving.php'>Historical facts about Thanksgiving Turkey</a><li><a href='american-thanksgiving.php'>Thanksgiving History and Origin</a><li><a href='canadian-thanksgiving.php'>Oktoberfest Celebrations Worldwide</a><li><a href='day-of-thanksgiving.php'>Gift Giving During Thanksgiving Adds That Special Touch</a><li><a href='funny-thanksgiving.php'>Love Cards</a><li><a href='great-thanksgiving.php'>Thanksgiving Flower Arrangements</a><li><a href='happy-thanksgiving.php'>Thanksgiving Gift Ideas</a><li><a href='history-of-thanksgiving.php'>The History of Thanksgiving</a><li><a href='hymn-of-thanksgiving.php'>We Gather Together</a>
        <li><a href='pilgrim-thanksgiving.php'>Thanksgiving History and Origin</a>
        <li><a href='thanksgiving-activities.php'>Thanksgiving  Cruise</a>
        <li><a href='thanksgiving-celebration.php'>Gift Giving During Thanksgiving Adds That Special Touch</a><li><a href='thanksgiving-dates.php'>Best Time To Go On a Disney Cruise</a><li><a href='thanksgiving-day-parade.php'>Vegetarian Thanksgiving - No Turkeys?</a><li><a href='thanksgiving-decorations.php'>Year Round Decorating Ideas For The Front Door</a>
        <li><a href='thanksgiving-dinner.php'>Great Thanksgiving  Sauces</a>
        <li><a href='thanksgiving-facts.php'>Historical facts about Thanksgiving Turkey</a><li><a href='thanksgiving-feast.php'>Tips for Thanksgiving Feast</a><li><a href='thanksgiving-food.php'>Thanksgiving Holiday Crafts:- Wonderful Decorations Kids Can Make</a><li><a href='thanksgiving-history.php'>Thanksgiving History and Origin</a><li><a href='thanksgiving-ideas.php'>Year Round Decorating Ideas For The Front Door</a>
        <li><a href='thanksgiving-pilgrims.php'>Thanksgiving Holiday Crafts:- Wonderful Decorations Kids Can Make</a><li><a href='thanksgiving-platter.php'>How to Host a Great Dinner Party in Seven Easy Steps</a><li><a href='thanksgiving-recipe.php'>Thanksgiving Recipes ideas</a><li><a href='thanksgiving-recipes.php'>A Deep Frying Guide to Turkey</a>
        <li><a href='thanksgiving-stuffing.php'>Vegetarian Thanksgiving - No Turkeys?</a><li><a href='when-is-thanksgiving.php'>Restaurant Quality Sauces At Home</a>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>