<html>
<head>
<title><? include('title.php') ?> :: The History of Thanksgiving</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><h1>The History of Thanksgiving</h1><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<br><p>Throughout history, the celebration of a bountiful harvest has been an annual occurrence.  Harvest festivals have been a tradition among all nations and races.  The Greeks, Egyptians, Romans, Chinese, and Hebrews have all had harvest celebrations, even before organized religion came to be.  In America, the first Thanksgiving celebration took place in 1621.  The Native Americans shared this event with the Pilgrims because the Pilgrims had learned to plant crops and hunt wild game in the New World according to Native American culture.  Without the help of the Native Americans, the colonists would have not survived their first winter nor would they have harvested bountiful crops.</p><p>The early Thanksgiving celebrations in America were not known as "Thanksgiving".  There were harvest celebrations that did not include what are staples in modern times such as cranberry sauce, turkey, and pumpkin pie.  It is entirely possible that wild fowl including turkey and duck were served, but turkey did not hold the sacred place it holds now.  It is thought that seafood was a major component of the harvest celebration due to the colonist's proximity to the Atlantic Ocean.  There could have been seasonal vegetables such as squash included in the festivities, but side dishes did play a major role in the feast.  Also, desserts such as pies and cakes were most likely not included due to a lack of sugar and obviously, there were no ovens in which to bake them.</p><div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<p>The Pilgrim's harvest festival is thought of as the first Thanksgiving, but in reality the term "Thanksgiving" was normally applied to a religious holiday until the 19th century.  In 1817 Thanksgiving Day was officially adopted by New York State as an annual event.  By 1863, President Abraham Lincoln declared a national day of Thanksgiving, and since then every president has given a Thanksgiving Day proclamation.  From 1939 to 1941 Franklin D. Roosevelt proclaimed the third Thursday in November as Thanksgiving Day, but in 1941 Congress passed a resolution declaring that Thanksgiving was to be held officially on the fourth Thursday of November.  Since that time, the holiday has been celebrated on that day.</p><p>The traditional dishes that are served on Thanksgiving evolved over a hundred years or more.  More than likely, the turkey is the only similarity modern celebrations have with the harvest festival celebrated by the Pilgrims. Our favorite desserts, such as pumpkin pie, were absent from the Thanksgiving festivities during WWII due to shortages of sugar.  Side dishes like green bean casserole and stuffing have been the products of modern times and an abundance of food supplies.</p><center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<p>We have many reasons to be thankful on Thanksgiving Day.  Our friends and family, our easy access to food, and modern conveniences are things that we tend to take for granted.  Early Thanksgiving celebrations were held to rejoice in the gift of a bountiful harvest and the very survival of the Pilgrims, a fact that we should remember each and every year.</p><div><table cellpadding="0" cellspacing="0" border="0"><tr><td valign="top"><div class="sig"><p>Are you a mom who d rather play than cook? If so, you won t want to miss <a target="_new" href="http://www.freequickrecipes.com">http://www.freequickrecipes.com</a>. And, if frugal cooking is your thing, then check out <a target="_new" href="http://www.freequickrecipes.com/frugal-cooking.php">http://www.freequickrecipes.com/frugal-cooking.php</a>.</p><p>Article Source: <a href="http://ezinearticles.com/?expert=Angela_Tyler">http://EzineArticles.com/?expert=Angela_Tyler</a></p></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>