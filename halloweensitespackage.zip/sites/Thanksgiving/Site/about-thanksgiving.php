<html>
<head>
<title><? include('title.php') ?> :: Historical facts about Thanksgiving Turkey</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><h1>Historical facts about Thanksgiving Turkey</h1>
<p class="author"><span style="font-weight: 400"><font size="1">By: Sean Carter</font></span> </p>
<div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<p class="articletext">
Prominent among all the symbols of Thanksgiving the turkey adorns the dining table of all Americans. As far as its nativity goes, the wild turkey is a native of North Mexico and the Eastern United States. People have the misconception that the bird belongs to the country Turkey but in reality the bird has nothing to do with the place sharing the similar name. Although the turkey is very famous among the Americans but Alaska has little to rejoice, as the place has no turkeys, accounting to the too very cold weather. The bird has an amazing combination of brown features and buff colored feathers on both its tail and wings. But in this case the male turkeys steal the show with their colorful plumage and the  wattle  which is the piece of skin hanging from their throat and beard like tuft on their chest. The female turkey is called the  hen . On account of its royal meat and the high quality egg that it lays, the turkey soon found a place for itself in the poultry farm of Mexico and then Europe towards the early 16th century.<br />
<br />
Research suggests that there are two species of turkeys, the North American Wild Turkey and the Central American Oscillated Turkey.<div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<br />
Zelda, a female wild turkey has lived in New York s Battery Park since 2003 Turkeys have been known by different names at different places. To name a few, it is called , dundjan in Maltese, tarnegol hodu in Hebrew and indiuk in the Russian language.<br />
<br />
As far as the history of the turkey for Thanksgiving goes, we need to dig into William Bradford's famous work   History of Plymouth Plantation . The Governor had sent four of his men for fowling and they had come back with turkeys, ducks and geese. The Bronze, Narragansett, White Holland and Bourbon Red are some of the common breeds of the American turkeys. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<br />
<br />
Benjamin Franklin had once said  The turkey is a much more respectable Bird and a true original Native of North America . In fact the turkey had become such a famous bird that the scientists cum statesman of America were in the idea of replacing the bald eagle, the national bird of America, to a turkey. Such was the liking for this particular species.<br />
<br />
A very famous event called the National Thanksgiving Turkey Presentation takes place every year at the White house where the President of America is presented with a turkey by the turkey industry. As per the tradition the President gives a  presidential pardon  to the turkey and it happily goes to a separate farm to live the rest of its life. This tradition of gifting turkey to presidents dates back to the year 1947 when the first National Thanksgiving Turkey was given to President Harry Trueman. The turkey to be gifted on the National Thanksgiving Day is given a special treatment unlike any other ordinary turkey. The turkeys to be gifted are separated for their flock and raised separately on the Trites farm. These turkeys are hand fed and a specially made to interact with the people to familiarize them with the local crowd. The year 2005 stood witness to the 58th anniversary of the National Thanksgiving Presentation and two turkeys were lucky enough to get the presidential pardon and went their ways merrily to live in Disneyland. Ever since the year of its beginning, every president has performed their task of pardoning a turkey.</p>

<p class="articletext">
</p>
<p class="articletext">
Sean Carter writes on holidays, <a href="http://www.123greetings.com/events/thanksgiving/" target="_blank"> Thanksgiving </a> and world events. He also writes on family, relationships, Christmas, religion, love and friendship. He is a writer with special interest in ecard industry and writes for <a href="http://www.123greetings.com" target="_blank"> 123greetings.com</a>. He also writes blogs on <a href="http://thanksgiving4all.blogspot.com" target="_blank">thanksgiving4all.blogspot.com</a> >Thanksgiving Blogspot</a></p></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>