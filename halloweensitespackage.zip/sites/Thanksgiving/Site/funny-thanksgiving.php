<html>
<head>
<title><? include('title.php') ?> :: Love Cards</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>Love Cards&nbsp;&nbsp;</H1><FONT size=-1> by Zeeshan</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Isn't love the greatest feeling of all? We all love our mother, father, sister or brother, but nothing compares to the feeling of being in loved with someone. We can all talk about this feeling, but we can truly understand it once we feel it. There are now so many ways to express your feelings. And one of them is by sending love cards. "I love you", "I miss you", "thinking of you" and many many other thoughts can be sent to your beloved one, to your family or friends with the help of love cards. In the unfortunate case the dear ones live far away, you now have the option to send them a card that will express your feelings to them. <P>But first, let's learn something about love cards. The most popular love cards are obviously the valentine's ones. The first love card is attributed to Charles, the Duke of Orleans. In 1415, because he was imprisoned in the Tower of London, he chose to send his thoughts to his lonely wife this way. He wrote romantic verses and sent them as small letters to his beloved one. You can see this love card, as it is preserved in the British Museum. These cards became more and more popular, that, in the 16th century, because he feared for the souls of his English flock, sermonized against them. <P>Years after that, by the end of the 18th century, manufactured love cards, decorated with hearts, cupids, flowers and other love signs appeared on the market. From that moment, love cards became the most popular way to show your love to someone. The love cards were hand painted, decorated with silk, laces or satin, glass filigrees, flowers, gold-leaf and even perfumed sachets. You could even consider them works of art. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>The most popular love cards are obviously the Valentine's love cards. Anyway, here is the story of Valentine's Day. Around the year 270 The Roman Emperor Claudius-II forbade his soldiers to marry. He thought that marriage causes emotional disorders and the soldiers would concentrate less on their duties this way. At that time, a priest named Valentine saw that people suffered so he decided to perform marriages in secret. Unfortunately, Claudius found out about this and arrested the priest. After that, on 24th of February 270, Valentine was executed. Before his death in the prison, the priest Valentine wrote a love letter to his own sweetheart, Asterius, on the 14th of February, and signed it "from your Valentine". Since that moment, these words have lived on and Valentine has been remembered for his romantic compassion. <P>Nowadays, you can find love cards about everywhere. There are thousands of thousands of store that sell such things. Also, the internet is probably the main source of love cards. You can find hundreds of specialized love cards. You can customize one with your message and send it to someone, or you can have one emailed to him or her. E-cards are now very popular, and you can find one on any theme: love, hate, laughs, fun, friendship and so on. They are even customized to fit all the occasions, like birthdays, Christmas, Easter, Thanksgiving Day, Halloween and so on. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>So, don't bother thinking on ways to show your affection to someone. It is much easier, and sometimes cutter to send someone a nice love card. You can come up with your own message, or you can choose one that already has one, and just sign it. More, you can express your feelings with funny love cards or with singing love cards. I bet your girlfriend will be impressed if you will send her a love card with a nice message and with tones of her favorite song.<BR> <P><B>About the Author</B></P> <P>Copyright � <A href="http://www.lovingwhisper.com/" target=_new>LovingWhisper.com</A>. Express love with <A href="http://www.lovingWhisper.com/love-cards.htm" target=_new>Love Cards</A>, <A href="http://www.lovingwhisper.com/love-cards/i-miss-you.htm" target=_new>I Miss You Cards</A> and <A href="http://www.lovingwhisper.com/love-cards/i-love-you.htm">I Love You Cards</A></P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>