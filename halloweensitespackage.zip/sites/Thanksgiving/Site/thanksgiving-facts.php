<html>
<head>
<title><? include('title.php') ?> :: Historical facts about Thanksgiving Turkey</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>Historical facts about Thanksgiving Turkey&nbsp;&nbsp;</H1><FONT size=-1> by Sean Carter</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>The festival of thanksgiving has several symbols attached to it, but the moment we think of the fourth Thursday of November, its the turkey that that's prime on our minds. <P>Prominent among all the symbols of Thanksgiving the turkey adorns the dining table of all Americans. As far as its nativity goes, the wild turkey is a native of North Mexico and the Eastern United States. People have the misconception that the bird belongs to the country Turkey but in reality the bird has nothing to do with the place sharing the similar name. Although the turkey is very famous among the Americans but Alaska has little to rejoice, as the place has no turkeys, accounting to the too very cold weather. The bird has an amazing combination of brown features and buff colored feathers on both its tail and and wings. But in this case the male turkeys steal the show with their colorful plumage and the "wattle" which is the piece of skin hanging from their throat and beard like tuft on their chest.The female turkey is called the "hen". On account of its royal meat and the high quality egg that it lays, the turkey soon found a place for itself in the poultry farm of Mexico and then Europe towards the early 16th century. <P>Research suggests that there are two species of turkeys, the North American Wild Turkey and the Central American Ocellated Turkey. Zelda,a female wild turkey has lived in New York's Battery park since 2003 Turkeys have been known by different names at different places. To name a few, it is called , dundjan in Maltese, tarnegol hodu in Hebrew and indiuk in the Russian language. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>As far as the history of the turkey for Thanksgiving goes, we need to dig into William Bradford's famous work " History Of Plymouth Plantation". The Governor had sent four of his men for fowling and they had come back with turkeys, ducks and geese. The Bronze, Narragansett, White Holland and Bourbon Red are some of the common breeds of the American turkeys. <P>Benjamin Franklin had once said "The turkey is a much more respectable Bird and a true original Native of North America". In fact the turkey had become such a famous bird that the scientists cum statesman of America were in the idea of replacing the bald eagle, the national bird of America, to a turkey. Such was the liking for this particular species. <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>A very famous event called the National Thanksgiving Turkey Presentation takes place every year at the White house where the President of America is presented with a turkey by the turkey industry. As per the tradition the President gives a "presidential pardon" to the turkey and it happily goes to a separate farm to live the rest of its life. This tradition of gifting turkey to presidents dates back to the year 1947 when the first National Thanksgiving Turkey was given to President Harry Trueman.The turkey to be gifted on the National Thanksgiving Day are given a special treatment unlike any other ordinary turkey. The turkeys to be gifted are separated for their flock and raised separately on the Trites farm. These turkeys are hand fed and a specially made to interact with the people to familiarize them with the local crowd. The year 2005 stood witness to the 58th anniversary of the National Thanksgiving Presentation and two turkeys were lucky enough to get the presidential pardon and went their ways merrily to live in Disneyland. Ever since the year of its beginning, every president has performed their task of pardoning a turkey.<BR> <P><B>About the Author</B></P> <P>Sean Carter writes on holidays, <A href="http://www.123greetings.com/events/christmas/">Christmas</A> and events around the world. He also writes thanksgiving facts at <A href="http://www.123greetings.com/events/thanksgiving ">Thanksgiving </A>. He is a writer with special interest in ecard industry. He also writes a blog on <A href="http://thanksgiving4all.blogspot.com/">Thanksgiving </A></P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>