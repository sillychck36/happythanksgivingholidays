<html>
<head>
<title><? include('title.php') ?> :: Oktoberfest Celebrations Worldwide</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>Oktoberfest Celebrations Worldwide&nbsp;&nbsp;</H1><FONT size=-1> by Jane S. Roseen</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P>Can't make it to Munich, Germany, to the official Oktoberfest? Why not check out one of the many other Oktoberfests celebrated around the world. The largest Oktoberfest outside Germany is held in Kitchener-Waterloo, Ontario, around the time of Canadian Thanksgiving. Another large event is held in Cincinnati, Ohio--with over 500,000 visitors during the 2002 Oktoberfest-Zinzinnati. The pseudo-Bavarian village of Leavenworth, Washington holds Oktoberfest during the first two weeks in October yearly. The city of New Braunfels, Texas also holds an Oktoberfest, as does Addison,Texas; Mount Angel, Oregon; La Crosse, Wisconsin; Lancaster County, Pennsylvania; Panama City, Florida; and the Bavarian-reproduction town of Helen, Georgia. <P>A huge Oktoberfest is held in the Brazilian city of Blumenau (more than 600,000 visitors in 2004), and many other Brazilian cities founded by Germans have their own Oktoberfest, such as Santa Cruz do Sul (more than 500,000 visitors in 2004), Rol�ndia, S�o Jos� do Cedro, Seara and Itapiranga. <P>In Argentina, a town called Villa General Belgrano in the C�rdoba Province has an Oktoberfest that is well-known and the biggest in the country. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>Hong Kong has celebrated the Oktoberfest since 1991 and it is organized by the Marco Polo Hong Kong Hotel. Ho Chi Minh City, Vietnam has celebrated Oktoberfest since 1992 and it is held at the Hotel Equatorial. Not called "Oktoberfest", but very similar in character, is the Cannstatter Wasen in Stuttgart which starts one week later and is the second largest fair in the world. Smaller beer festivals similar to the Oktoberfest are common in Germany and take place throughout the year in most bigger German cities. <P>Inspired by a joke on The Simpsons, there is now a Scottish version called the Scotchtoberfest.<center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<BR> <P><B>About the Author</B></P> <P>Author Bio Jane S. Roseen is the Owner and President of Harmony Sweets, an international gourmet chocolate shop. Harmony Sweets' mission focuses on individual consumers purchasing gourmet chocolates from around the world for their friends and relatives, as well as corporate gift-giving. Gourmet chocolate gift baskets and personalized chocolates are also available. <P>Website: <A href="http://www.harmonysweets.com">http://www.harmonysweets.com</A> </P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>