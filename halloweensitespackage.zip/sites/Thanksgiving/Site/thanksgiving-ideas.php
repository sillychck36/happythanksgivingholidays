<html>
<head>
<title><? include('title.php') ?> :: Year Round Decorating Ideas For The Front Door</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><h1>Year Round Decorating Ideas For The Front Door</h1><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<br><p>The front door of your home is the first thing that visitors will see.  You can make a good impression on your guests and visitors by adding some special decorative touches to this area.  These decor accents do not have to be elaborate or expensive.  Many times just one or two specially selected pieces will go a long way.  By decorating the front doorway area you can lend a nice touch to your home, and make your guests feel especially welcomed.  Here are some ideas for making the most of your decorating area with ideas to give special pizzaz to your front door.</p><p>Hang door garland.  This can be in any theme and will cover a large amount of space on the front door.   Make sure you choose something that will be relatively weather resistant, and will not fade easily.  A garland of fall colored leaves would make a wonderful autumn design.  For Christmas, holly or poinsettias could be used to make a similar garland.</p><div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<p>Display a large wreath or other floral display with the use of an over-the-door wreath hanger. Try making your own wreath out of natural materials like pine cones.  This can be easily accomplished by using a glue gun and adding some decorative floral picks.  I usually make my own Christmas wreath by using a pre-made wreath shape, and adding Christmas floral picks or handmade bows.  I purchase these inexpensively from the Dollar Store.</p><p>Add a door knob hanger.  This could be as elaborate as a handmade, one-of-a-kind piece, or as simple as a colored ribbon with bells attached.  For seasonal themes, a strand of dried corn or even small fall leaves would make a nice hanger.  Snowman and poinsettias would be fun ideas for Christmas or Winter.</p><center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<p>Seasonal door decorations are a fun way to decorate the front door.   For autumn you could use a fall themed wreath with apples, fall leaves, even tiny pumpkins.  Thanksgiving ideas include the cornucopia or dried corn.  For the past couple of years, I have used a heavy wrapping paper to  wrap  my front door to look like a present.  I usually use a bright red foil paper, then add a handmade wreath.</p><div><table cellpadding="0" cellspacing="0" border="0"><tr><td valign="top"><div class="sig"><p>Dee Marie is a successful freelance writer who enjoys decorating.  To get more ideas for a <a target="_New" href="http://www.dktshopping.com/gardening-decorate/Door-Decoration---Door-Knob-Hangers.html">front door decoration</a> or for more <a target="_New" href="http://www.dktshopping.com/gardening-decorate/index.html">unique decor accessories</a>, please visit <a target="_new" href="http://www.DKTShopping.com">http://www.DKTShopping.com</a></p><p>Article Source: <a href="http://ezinearticles.com/?expert=Dee_Marie">http://EzineArticles.com/?expert=Dee_Marie</a></p></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>