<html>
<head>
<title><? include('title.php') ?> :: Thanksgiving History and Origin</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><h1>Thanksgiving History and Origin</h1><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<br><p>One of the biggest and warmest holidays of the United States, Thanksgiving has its history and origin way back in centuries. There are various instances of thanksgiving observances in history, all of which bear resemblance to the modern celebrations of Thanksgiving; but the generally accepted and circulated view is that the modern day American Thanksgiving has its origin in 1621, when the Pilgrims, or the English settlers and the Native Americans celebrated a three-day long feast in Plymouth, Massachusetts. But quite contrary to this popular belief, the Pilgrims were never the first to have a Thanksgiving feast. Feasts celebrating a good harvest existed well before the Pilgrims or the settlers arrived. Nevertheless, it s true that these Pilgrims held a Thanksgiving feast (more aptly, a feast to say  thanks ) in the first year of their survival in America</p><p>Following this Pilgrim s 1621 Thanksgiving observance, began the Thanksgiving tradition of holding feasts after a good harvest. People usually celebrate Thanksgiving to mark the Autumn harvest and make merry in the plentiful yield. There is, however, a long tradition of celebrating the harvest throughout history. It might interest you to know that even the ancient Greeks and Romans had their respective harvest celebrations with music, parades and feasts quite like today s Thanksgiving celebrations. People in ancient China also had their harvest festival with families feasting together on  moon cakes  (round yellowish cakes). This was to celebrate the full moon and, as a matter of fact, the Chinese still celebrate this as their Moon Festival with much hype and hoopla ! Then again, there s the harvest festival of the Jews. The Jewish harvest fest, Sukkot, is celebrated for eight days and is an occasion to catch up with the family on feasts and to be thankful for a good year. The British Isles too has a harvest festival called the Lammas, which marks the beginning of the harvest season.</p><div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<p>Now, whatever the history and origin, Thanksgiving today is primarily a day set aside in the most part of North America to show gratitude and be thankful to God. Feasts and family reunions are a regular trend for Thanksgiving in North America. In the United States, Thanksgiving is celebrated on the fourth Thursday in November every year. But in Canada, the harvest season ends a little earlier in the year. Hence in Canada, Thanksgiving is celebrated on the second Monday in October. The Canadians have a three-day long Thanksgiving weekend and the holiday is not as significantly hyped here as in the United States. The Canadians also do not get enough time for a convenient homecoming. So they reserve the family reunions for the Christmas holiday.</p><p>The Thanksgiving holiday has serious religious shades for the Roman Catholic Quebecers, who call it l'Action de Gr ce. Thanksgiving has a long-standing history in Europe; it is associated with the harvest festivals held there.</p><center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<p>So then, as you see, celebrating harvest is quite old. And so is the thanksgiving act to thank the Almighty for all the good things He has given us ! And all these harvest festivities, although having cultural differences, are common in spirit to the modern American Thanksgiving.</p><div><table cellpadding="0" cellspacing="0" border="0"><tr><td valign="top"><div class="sig"><p>Sean Carter writes on holidays, <a target="_new" href="http://www.123greetings.com/events/thanksgiving">thanksgiving</a> and celebrations around the world. He also writes on family, relationships,womens issues  <a target="_new" href="http://www.123greetings.com/birthday">birthdays</a>, inspiration, religion, love and friendship. He is a writer with special interest in ecard industry. He writes for <a target="_new" href="http://www.123greetings.com"> 123greetings.com</a></p><p>Article Source: <a href="http://ezinearticles.com/?expert=Sean_Carter">http://EzineArticles.com/?expert=Sean_Carter</a></p></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>