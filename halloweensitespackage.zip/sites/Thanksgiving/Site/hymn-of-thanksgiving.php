<html>
<head>
<title><? include('title.php') ?> :: We Gather Together</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
a:link {
	color: #0000CC;
}
a:visited {
	color: #0000CC;
}
a:hover {
	color: #FF0000;
}
a:active {
	color: #0000CC;
}
-->
</style></head>
<body bgcolor="#FFFFFF">

<table width="780" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td bgcolor="#D7F8C9"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="images/thanksgiving_01.jpg" width="780" height="130" alt=""></td>
      </tr>
      <tr>
        <td bgcolor="#D7F8C9"><p align="center"><H1>We Gather Together&nbsp;&nbsp;</H1><FONT size=-1> by Beverly Youngs</FONT><div style='float:left; width:250px; height:250px; margin: 5px'>
<? include('ad1.php') ?>
</div>
<BR><BR> <P> <P>We gather together to give ask the Lord's blessing. Words paraphrased from am old hymn. <P>It seem that I have heard nothing lately, even from myself, except complaints and descriptions of what we don't have or can't afford. Followed by dire predictions of our future. <P>I agree that things are really bad economically and with society. We are divided on almost every issue, allover the world. Yes, things will probably get worse. BUT - <P>Do You walk miles in the burning sun to carry home the days prescious water? <P>Do you live in a shack amongst people who scare you to death? <P>When was the last time you slept on the street while the snow sifted around you? <P>Is there civil war blasting everything around you? <P>Have you had to flee from your home in fear of death on your own familiar street? <P>Do you suppose, even for a minute. That you have something to be thankful for? <P>Even as I say this, I'm sure some of our fellow readers answered "yes" to some of the above questions. <P>But for most of us, these questions remind us of exactly how well off we are, how lucky to have even humble homes to shelter us from the cold and the heat and the vagaries of the weather. To put supper on the table. And lunch. And breakfast, whether or not it is fancy. To have clothes to keep us warm. <P>It may be time to take stock and be truly thankful. <div style='float:right; width:120px; height:240px; margin: 5px'>
<? include('ad2.php') ?>
</div>
<P>I am thankful that I can still type, even though my hands don't work much any more. And that I have the opportunity to reach out to you all and offer help or just listening. <P>I am thankful for my home, my pets, that my children love and respect me., that I have a wheelchair to give me a sense of dignity, and an income even if small. I am grateful for more than I can mention to you. <P>Thanksgiving is this month here in the United States. <P>I heard a grumble yesterday at physical rehab, that there wasn't much to be grateful for this year. <P>Don't believe it. We are all blessed everyday with the things we take for granted. I promise myself that I will stop and remember all that is good. <P>Happy Thanksgiving. <P>BEV <center><div style='width:468px; height:60px;'>
<? include('ad3.php') ?>
</div></center>
<P>Try making a list of all the things you have to be thankful for. It will make your world look brighter. <BR> <P><B>About the Author</B></P> <P>Beverly Youngs is author/oublisher/editor and lecturer. See her site at <A href="http://www.cyber-seniors">http://www.cyber-seniors</A> where you can do almost anything without leaving the site.</P></p>
          <p align="center"><a href="index.php"><strong>SITE MAP</strong></a> </p></td>
      </tr>
      <tr>
        <td><img src="images/thanksgiving_03.jpg" width="780" height="88"></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>